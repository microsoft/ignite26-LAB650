---
document_id: EF-046
account: EagleFord
document_date: 2026-10-15
document_type: "Adoption and operations report"
stage: "Adoption"
author: "Lena Ortiz and Jo Ellis"
participants: "Lena Ortiz; Jo Ellis; Dana Brooks; Caleb Turner; Tessa Grant"
synthetic: true
---

# Early adoption snapshot: use is promising, value is not yet proven

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Reporting window

This snapshot covers first-wave production from October 12 through the October 15 morning cutoff. It is intentionally short and should not be called a quarterly performance report.

## Activity and cohort definitions

| Measure | Current value | Definition |
|---|---:|---|
| Authorized first-wave users | 40 | Named users at two live locations |
| Users with a genuine request or approval action | 34 | 85% of authorized first-wave users |
| Newly submitted production requests | 42 | Excludes migrated carryover and pilot requests |
| Completed new requests | 27 | Dynamics PO issued by cutoff |
| Open new requests | 15 | Not assigned zero duration |
| Completed-cohort median | 1.7 calendar days | Early, short-cohort observation only |

The twenty-three migrated carryover items are reported separately and do not enter these new-request cycle calculations. The 240 enterprise entitlement is not the appropriate denominator for two-site adoption.

## User experience

Most positive comments concern knowing who owns the next step. Caleb reported fewer informal “did you get it?” calls, but no structured call-volume study has been completed.

Six authorized users have no recorded genuine action in the window. Four had no relevant request or approval due; two need individual follow-up. Neither absence should automatically be labeled resistance or training failure.

## Operating issues

Three requesters asked about unsent attachments after weak connectivity. The system messages behaved as designed, but the training reminder should remain prominent. Procurement also received one request with an incomplete operational description; the clarification loop stayed visible.

No evidence in this snapshot supports claiming the enterprise target of 2.5 days has been achieved. Fast requests finish first, and fifteen remain open. The 1.7-day median is not directly comparable to a mature baseline without a longer window and request-mix review.

## Benefits tracking

No realized annual savings is reported. Jo will repeat the handling-effort study after a stable operating period. Dana and finance will evaluate actual expedite charges. Nadia will validate or reject the leakage assumption independently.

## Actions

Lena will contact the two users needing help. Tessa will preserve the difference between training completion, active use, and business benefit in the October 20 review. Owen will continue monitoring integration states through launch support.

**Recommendation:** maintain the first-wave scope until the team has enough evidence to decide whether to add locations responsibly.

## Related records

- [EF-029: Pilot results: measurable progress with two conditional acceptance cases](../03_validation/29_pilot-results-report.md)
- [EF-031: Business case: a thin first-year base case, not guaranteed cash savings](../04_commercial/31_business-case-model.md)
- [EF-045: Go-live steering meeting: two sites live, ten still gated](../05_delivery/45_go-live-steering-meeting.md)
- [EF-047: Launch escalation thread: who owns a request stuck in processing?](../05_delivery/47_launch-escalation-email.md)
- [EF-048: Early account review in QBR format: evidence before expansion](../05_delivery/48_early-account-review.md)
