---
document_id: EF-047
account: EagleFord
document_date: 2026-10-16
document_type: "Customer escalation email thread"
stage: "Adoption support"
author: "Lena Ortiz, Customer Success Manager"
participants: "Caleb Turner; Dana Brooks; Owen Park; Riley West; Lena Ortiz; Avery Stone"
synthetic: true
---

# Launch escalation thread: who owns a request stuck in processing?

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Initial message

**From:** Caleb Turner <caleb.turner@eagleford.example>  
**To:** Dana Brooks; Lena Ortiz  
**Sent:** October 16, 2026, 08:15 UTC  
**Subject:** Request EF-P-0047 still says ERP processing

The replacement fitting request is approved but has not shown a PO number. The field team is asking whether to submit it again. Please confirm who is handling this. I do not want us to repeat the June confusion.

## Response from Lena, 08:24 UTC

Please do not create a second request. Dana owns the business escalation and Owen's team owns the ERP reconciliation. I have opened the support record with EF-P-0047 as the business reference. We will update this thread by 09:00 UTC even if the investigation is still open.

The request's current state is not confirmation that a PO exists. We are checking the financial outcome before any replay.

## Technical update from Riley, 08:48 UTC

Dynamics rejected the transaction because the cost center was retired after the previous reference-data refresh. No PO was created for this business key. The request remains approved but blocked on a financial-reference correction.

This is not the June duplicate-callback defect. We found no repeated callback or duplicate financial transaction. The missing alert owner in the new reference-error queue delayed the operator response.

## Dana's decision, 09:02 UTC

Procurement will select the authorized active cost center and route the material change through the required approval step. We will not ask IT to substitute a value just to clear the queue.

Owen should assign the reference-error queue to a named operator and deputy. Lena should make the requester-facing processing-issue guidance easier to find.

## Closure update, 10:10 UTC

The corrected and reapproved request was processed using the controlled revision of the original business request. The ERP PO reference was reconciled and the requester notified. No replacement request was created.

## Lessons and actions

- Owen: add reference-data retirement detection and owner validation to the operational checklist.
- Riley: confirm the deputy receives the same queue alert.
- Lena: add this case to administrator coaching without presenting it as user error.
- Avery: remain informed but do not become the support dispatcher.

## Account implication

The customer is testing the operating model after sale. A prompt acknowledgment helped, but the alert-ownership gap is a real defect in handoff. The early account review must include it rather than report a clean launch with no issues.

## Related records

- [EF-013: Integration mapping workshop: fields, states, and replay rules](../02_solution_design/13_integration-mapping.md)
- [EF-027: Pilot incident report: duplicate callbacks without duplicate purchase orders](../03_validation/27_pilot-integration-incident.md)
- [EF-041: Sales-to-success handoff: promises, limitations, and the customer narrative](../05_delivery/41_sales-to-success-handoff.md)
- [EF-046: Early adoption snapshot: use is promising, value is not yet proven](../05_delivery/46_early-adoption-snapshot.md)
- [EF-048: Early account review in QBR format: evidence before expansion](../05_delivery/48_early-account-review.md)
