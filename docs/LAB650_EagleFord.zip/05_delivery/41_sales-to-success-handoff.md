---
document_id: EF-041
account: EagleFord
document_date: 2026-09-28
document_type: "Internal handoff document"
stage: "Implementation handoff"
author: "Avery Stone and Lena Ortiz"
participants: "Avery Stone; Lena Ortiz; Marcus Bell; Rowan Patel; Quinn Foster"
synthetic: true
---

# Sales-to-success handoff: promises, limitations, and the customer narrative

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Why EagleFord bought

The customer wants fewer ambiguous request handoffs, clearer ownership, and better control between the field and the financial system. Maya approved the purchase despite a thin first-year modeled economic case because Luis and Dana committed to a controlled operating change.

Do not open implementation by promising large cash savings. The base $253,368 modeled annual value includes capacity and unvalidated leakage assumptions. No headcount reduction is planned.

## Commercial facts to preserve

Three-year term begins October 1. Annual subscription is $180,000 for 240 named users across twelve locations. Implementation totals $72,000 including the $18,000 paid pilot credit, leaving $54,000 in two $27,000 milestones. Total economic commitment is $612,000 including the pilot, not recurring revenue.

Subscription entitlement is broader than initial deployment. The first wave is North Mesa and Red Creek only. There is no promise that all twelve locations launch in October.

## Stakeholder handling

Dana is the working champion and values direct, accurate communication. Luis owns the operational sponsorship. Maya challenges financial labels. Priya expects explicit architecture boundaries. Owen needs a runbook he can operate. Simone expects retained evidence, not assurances. Caleb will tell us if the field process is too cumbersome.

Coordinate material updates through Dana and Tessa. Do not bypass them to create executive pressure for adoption.

## Product and scope boundaries

- No full offline submission; recoverable text is not an offline transaction.
- No invoice automation, supplier onboarding, or warehouse inventory.
- No safety authorization.
- Dynamics remains financial system of record.
- Additional users and new workflow families require written scope review.

## Technical history

The June 18 incident caused fourteen minutes of degraded pilot processing and seven requests needing reconciliation. No duplicate PO was observed; callback state handling still required a fix. Preserve replay and restart tests in release validation.

T13 delegation expiry and T22 audit export were accepted on August 20 with customer-owned controls and evidence. Revalidate configuration before production. Seven-year retention is in EagleFord-controlled immutable storage; application search is thirteen months.

## Success plan

Track field adoption, open cohorts, handling effort, emergency classification, actual expedite charges, and integration exceptions. Do not annualize a few launch days into realized ROI.

## Handoff actions

Marcus owns implementation execution. Lena owns ongoing success planning. Rowan will remain available for the integration transition, not serve as the permanent queue operator. Avery owns commercial continuity and will attend the initial review.

**Acceptance:** Lena and Marcus acknowledge the limitations, owner map, commercial reconciliation, and delivery gates. The handoff is not complete merely because the CRM stage changed.

## Related records

- [EF-027: Pilot incident report: duplicate callbacks without duplicate purchase orders](../03_validation/27_pilot-integration-incident.md)
- [EF-035: Security closure record: pilot conditions resolved with production controls](../04_commercial/35_security-closure-record.md)
- [EF-040: Executed agreement summary and order reconciliation](../04_commercial/40_executed-agreement-summary.md)
- [EF-042: Implementation kickoff: a phased launch with real go/no-go gates](../05_delivery/42_implementation-launch-plan.md)
- [EF-048: Early account review in QBR format: evidence before expansion](../05_delivery/48_early-account-review.md)
