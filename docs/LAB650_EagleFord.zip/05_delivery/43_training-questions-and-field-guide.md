---
document_id: EF-043
account: EagleFord
document_date: 2026-10-05
document_type: "Training transcript and field guide"
stage: "Implementation"
author: "Lena Ortiz, Customer Success Manager"
participants: "Lena Ortiz; Caleb Turner; Dana Brooks; Tessa Grant; Jo Ellis"
synthetic: true
---

# Training clinic: real user questions and corrected assumptions

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Clinic format

The refresher clinic uses real workflow scenarios with fictional training transactions. It is designed for first-wave users, not all 240 licensed people. Thirty-six of forty attended the scheduled sessions; four require make-up sessions before activation.

## Questions and answers

**Requester:** “I saved the form and can see the photo preview. Has procurement received it?”

**Lena:** “Not necessarily. Look for the server-confirmed submitted state and request ID. A saved text draft does not guarantee that the image was uploaded. If the warning says unsent, follow that instruction.”

**Caleb:** “If it is urgent, should I create another request?”

**Dana:** “No. Use the existing request ID and the escalation contact. Duplicate requests can create confusion even if the integration prevents duplicate POs.”

**Approver:** “Can I delegate everything while I am away?”

**Dana:** “Only within your authorized scope and with an end date. A delegate cannot approve their own request. If the system denies an action, do not ask somebody to share an account.”

**Requester:** “Does approved mean I can tell the supplier to ship?”

**Lena:** “The PO-issued state is separate. Follow EagleFord's purchasing policy; the workflow is not a substitute for it.”

## Desk reference

| State | Meaning | User action |
|---|---|---|
| Draft / unsent | Not confirmed received | Complete or retry according to guidance |
| Submitted | In workflow queue | Track owner and respond to clarification |
| Awaiting approval | Authorized decision pending | Do not bypass authority |
| ERP processing | Approval recorded; PO not yet confirmed | Report an unusual delay using request ID |
| PO issued | ERP returned a PO reference | Follow normal supplier communication rules |
| Processing issue | Operator review required | Do not create a replacement request blindly |

## Readiness observations

Two participants initially selected a retired cost center from memory rather than the current list. The system rejected it correctly. This is a training and reference-data issue, not evidence that the approval engine is broken.

One user expected the emergency flag to skip a safety check. Miguel's existing policy was restated. No safety authorization is issued by FieldBridge.

## Actions

Tessa will schedule the four make-up sessions by October 8. Jo will separate training completion from first successful use. Caleb will keep the desk reference near the shared office workstation.

**Follow-up measure:** how many authorized users complete a genuine request or approval after launch, not how many attended a presentation.

## Related records

- [EF-024: Pilot enablement plan: teach the exception, not just the form](../03_validation/24_pilot-enablement-plan.md)
- [EF-042: Implementation kickoff: a phased launch with real go/no-go gates](../05_delivery/42_implementation-launch-plan.md)
- [EF-045: Go-live steering meeting: two sites live, ten still gated](../05_delivery/45_go-live-steering-meeting.md)
- [EF-046: Early adoption snapshot: use is promising, value is not yet proven](../05_delivery/46_early-adoption-snapshot.md)
