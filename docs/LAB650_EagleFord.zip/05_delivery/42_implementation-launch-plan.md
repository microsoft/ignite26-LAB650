---
document_id: EF-042
account: EagleFord
document_date: 2026-10-01
document_type: "Implementation plan"
stage: "Implementation"
author: "Marcus Bell and Tessa Grant"
participants: "Marcus Bell; Tessa Grant; Dana Brooks; Owen Park; Simone Reed; Lena Ortiz"
synthetic: true
---

# Implementation kickoff: a phased launch with real go/no-go gates

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Starting position

The enterprise term begins today. The subscription covers 240 named users across twelve locations, but the initial production wave remains North Mesa and Red Creek with forty users. Pilot history will be archived separately from production reporting.

Starting the subscription is not evidence that all locations are ready. The customer accepted this phased commercial and operating arrangement during negotiation.

## Milestones

| Date | Milestone | Gate |
|---|---|---|
| October 1 | Implementation kickoff | Owners and scope confirmed |
| October 5 | Requester and approver refresher training | Practical readiness, not attendance alone |
| October 8 | Open-request migration rehearsal | Reconciled IDs and no duplicate financial creation |
| October 9 | Configuration acceptance review | Authorities, access, export, and recovery evidence |
| October 12 | First-wave go-live | Joint operational go/no-go |
| October 20 | Early account review | Initial adoption and issues, not quarterly ROI |

These are planned milestones. A missed gate moves the relevant launch; it does not authorize an undocumented workaround.

## Production checklist

Owen must validate endpoint configuration, stable business keys, retry ownership, monitoring, and access for the designated operators. Simone must verify current role scopes and the audit-export destination. Dana must approve the authority matrix and substitute-approver rules.

The team will run a timed recovery rehearsal where the ERP accepts a request and the callback is lost. Marcus will not accept a slide describing the procedure in place of observed execution.

## Rollback and continuity

The controlled legacy route remains available for an incident. Each fallback request gets a reconciliation entry. Users must not submit the same purchase through both routes without operator guidance.

If launch is paused, communicate who is affected, what route to use, and what happens to existing requests. “Use email for now” without ownership would recreate the original problem.

## Deployment sequencing

Later locations need a sponsor, trained administrator, approved reference data, and a readiness review. Tessa will propose the next wave only after first-wave evidence is reviewed. There is no obligation to activate unused entitlements prematurely.

## Commercial checkpoint

Configuration acceptance and first-wave go-live each trigger a $27,000 implementation milestone. The paid $18,000 pilot is already credited; it must not be billed again.

**Open dependency:** backup integration-operator coverage. Owen will name a trained deputy before the October 9 review.

## Related records

- [EF-040: Executed agreement summary and order reconciliation](../04_commercial/40_executed-agreement-summary.md)
- [EF-041: Sales-to-success handoff: promises, limitations, and the customer narrative](../05_delivery/41_sales-to-success-handoff.md)
- [EF-043: Training clinic: real user questions and corrected assumptions](../05_delivery/43_training-questions-and-field-guide.md)
- [EF-044: Migration rehearsal: carry open work, not every historical message](../05_delivery/44_migration-rehearsal.md)
- [EF-045: Go-live steering meeting: two sites live, ten still gated](../05_delivery/45_go-live-steering-meeting.md)
