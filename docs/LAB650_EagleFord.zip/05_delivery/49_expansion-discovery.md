---
document_id: EF-049
account: EagleFord
document_date: 2026-10-22
document_type: "Expansion discovery notes"
stage: "Unqualified expansion"
author: "Avery Stone, Account Executive"
participants: "Dana Brooks; Luis Ortega; Owen Park; Avery Stone; Rowan Patel; Lena Ortiz"
synthetic: true
---

# Expansion discovery: warehouse visibility is a different problem

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Why the conversation happened

During the early account review, Luis mentioned that crews sometimes request a part already held at another location. Dana authorized a short discovery session to understand the issue. This is not a change to the signed procurement-intake scope.

## Customer examples

A Red Creek supervisor recently requested a spare coupling while a compatible part may have been stored at North Mesa. The team could not quickly establish whether the spare was available, reserved, obsolete, or correctly labeled.

Dana emphasized that procurement visibility and inventory availability are related but different. A request form can capture the question; it cannot establish reliable stock without an inventory process and data.

## Dialogue

**Luis:** “Could FieldBridge show us where the parts are?”

**Rowan:** “We should first identify your inventory system and the trustworthiness of its quantities. The current scope does not include warehouse inventory. I do not want to promise stock accuracy from a workflow screen.”

**Owen:** “Some counts are in a maintenance system, some in spreadsheets. We would need an owner for physical reconciliation.”

**Dana:** “Then the next step is not a quote. It is understanding which locations and materials are affected.”

## Qualification status

| Dimension | Current evidence |
|---|---|
| Business problem | Plausible; one example, not sized |
| Sponsor | Luis interested; no dedicated expansion sponsor appointed |
| Data owner | Not confirmed |
| Budget | None disclosed |
| Buying date | None agreed |
| Product fit | Unproven; warehouse functionality excluded from current agreement |
| Competing priorities | First-wave stability and two-site readiness assessments |

## Risks

Presenting this as an easy add-on could undermine trust and distract Owen from the current operating model. It could also blur the difference between twelve-location license coverage and additional product scope.

Any future integration with inventory would need security, authority, master-data, and support assessment. The current business case cannot be reused without new assumptions and evidence.

## Next steps

Dana will decide whether to nominate a warehouse or maintenance-data owner. Avery will provide a discovery outline, not pricing. Rowan will list information needed to evaluate fit, including reservation semantics and stock freshness.

Lena will keep expansion separate from success metrics for the existing rollout. No additional opportunity amount is included in the account forecast. Status is **unqualified expansion discovery**, not a committed upsell.

## Related records

- [EF-033: Commercial proposal: 240 named users and an explicit pilot credit](../04_commercial/33_pricing-proposal.md)
- [EF-040: Executed agreement summary and order reconciliation](../04_commercial/40_executed-agreement-summary.md)
- [EF-048: Early account review in QBR format: evidence before expansion](../05_delivery/48_early-account-review.md)
- [EF-050: Account next steps and unresolved questions as of October 23](../05_delivery/50_account-next-steps.md)
