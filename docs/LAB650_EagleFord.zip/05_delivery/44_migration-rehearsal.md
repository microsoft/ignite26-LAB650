---
document_id: EF-044
account: EagleFord
document_date: 2026-10-08
document_type: "Migration decision and reconciliation report"
stage: "Implementation"
author: "Owen Park, Enterprise Applications Manager"
participants: "Owen Park; Jo Ellis; Dana Brooks; Marcus Bell; Tessa Grant"
synthetic: true
---

# Migration rehearsal: carry open work, not every historical message

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Migration policy

Only active, in-scope requests without an existing financial outcome are candidates for production carryover. Historic pilot data remains a separate evaluation record. Closed legacy requests and supplier email attachments are not bulk-imported into production simply because they exist.

This policy follows the reference-call lesson: deciding which work belongs in the new process is a business decision, not a file-conversion task.

## Rehearsal counts

| Disposition | Count | Treatment |
|---|---:|---|
| Active requests with no PO and adequate context | 23 | Carry forward after owner confirmation |
| Requests already linked to an ERP PO | 9 | Keep ERP reference; do not recreate purchase |
| Withdrawn or duplicate legacy items | 6 | Retain in reconciliation record; no import |
| Items needing ownership clarification | 4 | Hold outside production until resolved |
| Total reviewed | **42** | All candidates accounted for |

These forty-two legacy candidates are not the 186-request pilot cohort. The two populations have different sources and purposes.

## Rehearsal behavior

The import creates a migration reference and preserves the original received date in a separate field. It does not pretend the request was newly submitted today or already approved. Requests needing fresh approval follow the current authority matrix.

The nine existing-PO items were checked against Dynamics. No new PO request was sent for them. The four ambiguous items remain on Dana's action list and are not silently assigned to an administrator.

## Defects found

One date field initially displayed the UTC day rather than the user's local display date. The underlying timestamp was correct. Marcus corrected the display mapping and Jo retested a boundary example.

Two descriptions exceeded the proposed display length. The import now preserves the full text while showing a readable preview; no material requirement is truncated.

## Acceptance evidence

Jo reconciled candidate counts and identifiers. Owen verified that migrated references do not collide with new request business keys. Dana reviewed approval treatment for the twenty-three carryover candidates.

## Remaining work

Tessa will obtain owner confirmation before the final import. Owen will repeat the no-duplicate-PO check after cutover. Production metrics will identify migrated requests so they do not distort new-request cycle-time comparisons.

**Decision:** rehearsal accepted with the four held items excluded. This does not constitute first-wave go-live approval, which remains scheduled for October 12.

## Related records

- [EF-023: Data-readiness findings: retired cost centers and ambiguous locations](../03_validation/23_data-readiness-findings.md)
- [EF-036: Reference-call summary: what another operator wished it had planned](../04_commercial/36_reference-call-summary.md)
- [EF-042: Implementation kickoff: a phased launch with real go/no-go gates](../05_delivery/42_implementation-launch-plan.md)
- [EF-045: Go-live steering meeting: two sites live, ten still gated](../05_delivery/45_go-live-steering-meeting.md)
