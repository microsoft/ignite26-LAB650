---
document_id: EF-045
account: EagleFord
document_date: 2026-10-12
document_type: "Steering committee decision record"
stage: "First-wave live"
author: "Tessa Grant, Transformation PM"
participants: "Luis Ortega; Dana Brooks; Priya Nair; Owen Park; Simone Reed; Tessa Grant; Marcus Bell; Lena Ortiz"
synthetic: true
---

# Go-live steering meeting: two sites live, ten still gated

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Readiness review

The team reviewed configuration acceptance completed October 9, training completion, open-request reconciliation, integration recovery evidence, and security checks. The four make-up trainees completed their sessions before activation.

Owen named a trained deputy integration operator, **Riley West**, and completed a supervised recovery rehearsal. Riley is an EagleFord IT operations colleague, not an additional commercial decision-maker.

## Decision

Authorize production use at **North Mesa and Red Creek**, with forty named first-wave users. The other ten licensed locations remain inactive pending readiness reviews. License entitlement does not replace operational acceptance.

## Gate evidence

| Gate | Evidence | Disposition |
|---|---|---|
| Authorities and delegation | Approved matrix; expiry and conflict tests | Accepted by Dana |
| Identity and location scopes | Current roster; negative-access tests | Accepted by Simone |
| ERP integrity | Lost-callback recovery and replay rehearsal | Accepted by Owen |
| Audit retention | Export delivery, alert, and readback | Accepted by Simone / Owen |
| Training | Forty users completed required training | Accepted by Tessa |
| Migration | Twenty-three carryover items confirmed; four held items excluded | Accepted by Dana |

## Executive discussion

Luis asked whether the team should announce all twelve locations as deployed. Dana declined: “We purchased enterprise coverage, but we have deployed two locations. Those are different statements.”

Priya requested a daily review of ambiguous ERP states during the first week, then a transition to normal operations if evidence supports it. Marcus confirmed that enhanced launch attention is temporary and should not be mistaken for the permanent service model.

## Financial milestone

Configuration acceptance and first-wave go-live satisfy the two implementation milestones of $27,000 each. Finance will reconcile them against the $54,000 implementation balance. The $18,000 pilot credit remains included in the $72,000 implementation total.

## Launch communications

Users receive the support route, emergency escalation reminder, and draft-versus-submitted guide. The fallback route remains controlled and reconciled. A general email inbox is not the sole recovery mechanism.

## Next actions

Jo will separate migrated carryover requests from new production requests. Lena will report adoption on October 15. Tessa will present a proposed second-wave readiness list at the early account review.

**Success boundary:** today's authorization confirms readiness for two sites. It does not demonstrate realized annual value, complete enterprise adoption, or qualification of additional product scope.

## Related records

- [EF-035: Security closure record: pilot conditions resolved with production controls](../04_commercial/35_security-closure-record.md)
- [EF-042: Implementation kickoff: a phased launch with real go/no-go gates](../05_delivery/42_implementation-launch-plan.md)
- [EF-043: Training clinic: real user questions and corrected assumptions](../05_delivery/43_training-questions-and-field-guide.md)
- [EF-044: Migration rehearsal: carry open work, not every historical message](../05_delivery/44_migration-rehearsal.md)
- [EF-046: Early adoption snapshot: use is promising, value is not yet proven](../05_delivery/46_early-adoption-snapshot.md)
- [EF-048: Early account review in QBR format: evidence before expansion](../05_delivery/48_early-account-review.md)
