# EagleFord fictional sales-account dataset

## Start here

This dataset contains **50 substantive Markdown documents** plus this navigation guide and a CSV manifest. It follows one fictional enterprise software sale from February 3 through October 23, 2026. No external research or real customer records were used. All organizations as portrayed, people, correspondence, meetings, quotations, transactions, and metrics are fictional; any resemblance is coincidental.

**Account:** EagleFord Energy, a fictional energy operator with twelve operating locations.  
**Seller:** Northstar Systems. **Product:** FieldBridge, procurement intake and approval software.  
**Scenario:** replace fragmented field-request handoffs while retaining Dynamics 365 Finance as the financial system of record.

This is a new sales scenario, separate from the musical-instrument customer-support workbook created earlier in this chat.

The materials deliberately include unresolved questions, disagreements, a pilot incident, evidence limitations, commercial concessions, and delivery risks. They are not fifty versions of a successful sales pitch. Read documents in date order to avoid treating later decisions as facts known earlier.

## Organization

- `01_discovery/`: account research hypotheses, interviews, process observations, baseline, and requirements.
- `02_solution_design/`: presentations, architecture, security intake, demonstrations, competitive assessment, and evaluation planning.
- `03_validation/`: pilot scope, test evidence, enablement, operational issues, and results.
- `04_commercial/`: economics, executive scrutiny, procurement, security closure, negotiation, and signature.
- `05_delivery/`: handoff, launch, migration, adoption, escalation, and expansion qualification.

Each document has YAML front matter, a unique identifier, date, author, participants, stage, and related-document links. Future-dated links are navigation aids, not evidence that an earlier participant knew later outcomes. The manifest provides body-word counts and SHA-256 checksums.

## People and account roles

| Customer stakeholder | Role |
|---|---|
| Maya Chen | CFO and economic buyer |
| Luis Ortega | VP Operations and executive sponsor |
| Dana Brooks | Director of Procurement and working champion |
| Priya Nair | CIO and architecture decision-maker |
| Owen Park | Enterprise Applications Manager and integration owner |
| Simone Reed | Security Lead |
| Nadia Hassan | AP Manager |
| Caleb Turner | North Mesa field supervisor |
| Miguel Santos | HSE Director |
| Erin Walsh | Commercial Counsel |
| Tessa Grant | Transformation PM |
| Jo Ellis | Procurement Operations Analyst and measurement owner |

| Seller stakeholder | Role |
|---|---|
| Avery Stone | Account Executive |
| Rowan Patel | Solutions Engineer |
| Quinn Foster | Regional VP Sales |
| Marcus Bell | Professional Services Lead |
| Lena Ortiz | Customer Success Manager |
| Grace Liu | Security Assurance Lead |
| Noah Evans | Commercial Counsel |

## Stable reference facts

- Baseline: approximately **1,200 requests/month**, **14,400/year**, median **4.8 calendar days** request-to-PO, **34 minutes** handling effort/request, **7.5%** emergency share.
- Pilot: **June 1–July 10, 2026**, **North Mesa and Red Creek**, **40 named users**, **186 requests**, **172 completed** and **14 open** at cutoff.
- Pilot observations: completed-cohort median **2.9 days**; effort study **21 minutes** versus 34 baseline; **11/186** emergency requests (about **5.9%**). These are observational results, not guaranteed enterprise benefits.
- UAT: **24 scenarios**, **22 passed**, **2 conditional** at pilot close; conditions tracked explicitly.
- Final scope: **240 named users**, twelve locations, phased deployment. The 240 includes requesters, approvers, and administrators; it is not 240 plus an extra requester allowance.
- Final agreement: signed **September 25, 2026**; term **October 1, 2026–September 30, 2029**; **$180,000 annual subscription**, **$72,000 one-time implementation**.
- Pilot fee **$18,000** is credited against implementation, leaving **$54,000** implementation balance. Total first-year economic cost is **$252,000** including the pilot; total three-year economic commitment is **$612,000** including the pilot. Remaining commitment after the paid pilot is **$594,000**.
- Annual list subscription was **$216,000**. The final reduction is **$36,000**, about **16.7%**. Earlier options and positions are historical proposals, not contradictions.
- Business-case base: **$253,368 annual modeled value**, including **$96,768 capacity value**, **$66,600 avoidable expedite cost**, and **$90,000 estimated leakage reduction**. It is not all cash savings. Base first-year modeled net benefit is only **$1,368**.
- Launch is phased. Only North Mesa and Red Creek are live by the final document; no record establishes that all twelve locations are deployed.

## Suggested exercises

1. Build an account chronology and identify when sponsorship became funding approval.
2. Extract requirements, owners, acceptance evidence, and residual conditions.
3. Reconcile quoted pricing, credits, and signed economic commitment.
4. Distinguish observed metrics, estimates, targets, and contractual promises.
5. Produce a handoff brief using only records available before September 28.
6. Find the integration incident, its root cause, and how the risk was closed or carried forward.
7. Decide whether the October expansion conversation is a qualified opportunity.
8. Compare the CFO's objections with the seller's internal forecast assumptions.

For temporal retrieval tests, filter by `document_date`. Do not use this README's end-state facts as if they appeared in early discovery.

## Document index

| ID | Date | Type | Document |
|---|---|---|---|
| EF-001 | 2026-02-03 | Internal account brief | [EagleFord account brief and initial sales hypothesis](01_discovery/01_account-brief.md) |
| EF-002 | 2026-02-05 | Email thread | [Introductory email thread: getting the right people into discovery](01_discovery/02_introductory-email-thread.md) |
| EF-003 | 2026-02-10 | Meeting transcript | [Discovery call transcript: where a request disappears](01_discovery/03_discovery-call-transcript.md) |
| EF-004 | 2026-02-12 | Internal sales planning note | [Stakeholder map and buying-process hypotheses](01_discovery/04_stakeholder-map.md) |
| EF-005 | 2026-02-17 | Interview transcript and findings | [Procurement and AP interview: rework before and after the PO](01_discovery/05_procurement-interview.md) |
| EF-006 | 2026-02-20 | Field observation notes | [North Mesa field observation: the five-minute request](01_discovery/06_north-mesa-field-observation.md) |
| EF-007 | 2026-02-24 | Measurement report | [Baseline measurement note: definitions before improvement claims](01_discovery/07_baseline-measurement.md) |
| EF-008 | 2026-03-03 | Workshop record | [Requirements workshop: must-haves, exclusions, and ownership](01_discovery/08_requirements-workshop.md) |
| EF-009 | 2026-03-06 | Requirements response | [FieldBridge RFI response and explicit capability gaps](01_discovery/09_rfi-response.md) |
| EF-010 | 2026-03-10 | Customer recap email | [Discovery recap email: the buying problem and the next gate](01_discovery/10_discovery-recap-email.md) |
| EF-011 | 2026-03-17 | Presentation summary | [Presentation summary: one request, four distinct states](02_solution_design/11_scenario-presentation-summary.md) |
| EF-012 | 2026-03-20 | Architecture decision record | [Solution architecture decision record: request workflow beside the ERP](02_solution_design/12_solution-architecture.md) |
| EF-013 | 2026-03-24 | Technical workshop and mapping specification | [Integration mapping workshop: fields, states, and replay rules](02_solution_design/13_integration-mapping.md) |
| EF-014 | 2026-03-27 | Security questionnaire response and gap log | [Security intake: evidence requested and statements not yet accepted](02_solution_design/14_security-questionnaire.md) |
| EF-015 | 2026-04-02 | Demonstration transcript | [Demonstration transcript: show the broken path](02_solution_design/15_demonstration-transcript.md) |
| EF-016 | 2026-04-06 | Customer feedback summary | [Demo feedback and revised evaluation scorecard](02_solution_design/16_demo-feedback-and-scorecard.md) |
| EF-017 | 2026-04-09 | Requirements specification | [Nonfunctional requirements and production-readiness gates](02_solution_design/17_nonfunctional-requirements.md) |
| EF-018 | 2026-04-14 | Internal competitive assessment | [Competitive assessment: a new platform is not the only option](02_solution_design/18_competitive-assessment.md) |
| EF-019 | 2026-04-17 | Risk register | [Evaluation risk register and unresolved dependencies](02_solution_design/19_evaluation-risk-register.md) |
| EF-020 | 2026-04-21 | Joint evaluation plan | [Mutual action plan: evidence gates through a possible purchase](02_solution_design/20_mutual-action-plan.md) |
| EF-021 | 2026-05-01 | Pilot scope and commercial summary | [Pilot statement of work: two locations, bounded evidence](03_validation/21_pilot-statement-of-work.md) |
| EF-022 | 2026-05-06 | Acceptance test plan | [Pilot test plan and evidence register](03_validation/22_pilot-test-plan.md) |
| EF-023 | 2026-05-13 | Data-quality assessment | [Data-readiness findings: retired cost centers and ambiguous locations](03_validation/23_data-readiness-findings.md) |
| EF-024 | 2026-05-20 | Training and change plan | [Pilot enablement plan: teach the exception, not just the form](03_validation/24_pilot-enablement-plan.md) |
| EF-025 | 2026-06-01 | Kickoff meeting transcript | [Pilot kickoff transcript: what success does and does not mean](03_validation/25_pilot-kickoff-transcript.md) |
| EF-026 | 2026-06-12 | Pilot checkpoint notes | [Pilot checkpoint: faster completed requests, incomplete evidence](03_validation/26_pilot-midpoint-review.md) |
| EF-027 | 2026-06-18 | Incident report and technical timeline | [Pilot incident report: duplicate callbacks without duplicate purchase orders](03_validation/27_pilot-integration-incident.md) |
| EF-028 | 2026-06-23 | Retest record and operating decision | [Corrective-action review: controlled replay and remaining pilot conditions](03_validation/28_workaround-and-retest.md) |
| EF-029 | 2026-07-10 | Pilot evaluation report | [Pilot results: measurable progress with two conditional acceptance cases](03_validation/29_pilot-results-report.md) |
| EF-030 | 2026-07-16 | Executive readout transcript | [Sponsor readout transcript: a recommendation is not funding](03_validation/30_sponsor-readout-transcript.md) |
| EF-031 | 2026-07-23 | Business-case analysis | [Business case: a thin first-year base case, not guaranteed cash savings](04_commercial/31_business-case-model.md) |
| EF-032 | 2026-07-30 | Financial review transcript | [CFO review transcript: capacity is not cash](04_commercial/32_cfo-review-transcript.md) |
| EF-033 | 2026-08-06 | Pricing proposal | [Commercial proposal: 240 named users and an explicit pilot credit](04_commercial/33_pricing-proposal.md) |
| EF-034 | 2026-08-13 | Negotiation workshop notes | [Procurement and legal redline workshop](04_commercial/34_procurement-and-legal-redlines.md) |
| EF-035 | 2026-08-20 | Security and control acceptance | [Security closure record: pilot conditions resolved with production controls](04_commercial/35_security-closure-record.md) |
| EF-036 | 2026-08-26 | Fictional reference-call summary | [Reference-call summary: what another operator wished it had planned](04_commercial/36_reference-call-summary.md) |
| EF-037 | 2026-09-03 | Negotiation transcript | [Commercial negotiation transcript: discount, scope, and implementation risk](04_commercial/37_commercial-negotiation-transcript.md) |
| EF-038 | 2026-09-10 | Internal deal approval memo | [Internal concession approval and forecast review](04_commercial/38_concession-approval-memo.md) |
| EF-039 | 2026-09-17 | Executive decision record | [Executive decision meeting: proceed for control, with accountable economics](04_commercial/39_executive-decision-meeting.md) |
| EF-040 | 2026-09-25 | Contract and order summary | [Executed agreement summary and order reconciliation](04_commercial/40_executed-agreement-summary.md) |
| EF-041 | 2026-09-28 | Internal handoff document | [Sales-to-success handoff: promises, limitations, and the customer narrative](05_delivery/41_sales-to-success-handoff.md) |
| EF-042 | 2026-10-01 | Implementation plan | [Implementation kickoff: a phased launch with real go/no-go gates](05_delivery/42_implementation-launch-plan.md) |
| EF-043 | 2026-10-05 | Training transcript and field guide | [Training clinic: real user questions and corrected assumptions](05_delivery/43_training-questions-and-field-guide.md) |
| EF-044 | 2026-10-08 | Migration decision and reconciliation report | [Migration rehearsal: carry open work, not every historical message](05_delivery/44_migration-rehearsal.md) |
| EF-045 | 2026-10-12 | Steering committee decision record | [Go-live steering meeting: two sites live, ten still gated](05_delivery/45_go-live-steering-meeting.md) |
| EF-046 | 2026-10-15 | Adoption and operations report | [Early adoption snapshot: use is promising, value is not yet proven](05_delivery/46_early-adoption-snapshot.md) |
| EF-047 | 2026-10-16 | Customer escalation email thread | [Launch escalation thread: who owns a request stuck in processing?](05_delivery/47_launch-escalation-email.md) |
| EF-048 | 2026-10-20 | Account review and presentation summary | [Early account review in QBR format: evidence before expansion](05_delivery/48_early-account-review.md) |
| EF-049 | 2026-10-22 | Expansion discovery notes | [Expansion discovery: warehouse visibility is a different problem](05_delivery/49_expansion-discovery.md) |
| EF-050 | 2026-10-23 | Account-team operating memo | [Account next steps and unresolved questions as of October 23](05_delivery/50_account-next-steps.md) |
