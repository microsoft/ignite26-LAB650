---
document_id: EF-017
account: EagleFord
document_date: 2026-04-09
document_type: "Requirements specification"
stage: "Technical validation"
author: "Priya Nair, CIO"
participants: "Priya Nair; Owen Park; Simone Reed; Rowan Patel; Grace Liu"
synthetic: true
---

# Nonfunctional requirements and production-readiness gates

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Applicability

This specification distinguishes pilot acceptance from enterprise production readiness. Targets are evaluation criteria until incorporated into a signed contract or approved operating procedure. It must not be used as evidence that Northstar has already committed to every proposed target.

## Requirements

| ID | Area | Evaluation expectation |
|---|---|---|
| NF-01 | Identity | Entra ID SSO, prompt removal through customer identity controls |
| NF-02 | Authorization | Enforced role and location restrictions; negative tests required |
| NF-03 | Performance | Routine form interaction feels responsive under agreed test conditions; report measured latency |
| NF-04 | Transaction integrity | Stable idempotency keys and no duplicate PO on replay |
| NF-05 | Availability | Proposed 99.9% monthly service commitment to be negotiated |
| NF-06 | Recovery | Proposed RTO 8 hours, RPO 4 hours; contractual review required |
| NF-07 | Audit | Approval actor, rule version, timestamps, state changes, export evidence |
| NF-08 | Accessibility | Test keyboard navigation and readable state/error messages |
| NF-09 | Weak connectivity | Explicit unsent state and recoverable text; offline transactions excluded |
| NF-10 | Operability | Named exception owner, runbook, alerting, and supervised replay |

## Interpretation of resilience

Purchase-request approval and ERP purchase-order creation are separate events. The request interface must not conceal uncertainty when a callback is lost. Monitoring should detect ambiguous outcomes and direct an operator to reconciliation, not encourage blind retries.

A service-recovery objective is not the same as a purchase-request recovery time. Even if FieldBridge recovers, EagleFord middleware and Dynamics may have their own delays. End-to-end restoration requires coordinated ownership.

## Audit retention proposal

Northstar proposes thirteen months of searchable in-application events. EagleFord proposes longer independent retention in its own immutable storage. The current working requirement is seven-year retention for the exported record set, subject to security and legal acceptance. These two periods serve different purposes and should not be conflated.

## Pilot versus production

The pilot may operate with supervised daily reconciliation and manually reviewed audit exports. Production must demonstrate the scheduled export, failure alerting, a successful restore/readback check, and segregation-of-duties controls.

For delegation, a controlled pilot workaround may use an approved substitute approver without automated expiry. Enterprise rollout requires an enforceable expiry mechanism or an approved equivalent reviewed by Dana and Simone.

## Signoff responsibilities

Priya accepts architecture; Simone accepts security controls; Owen accepts integration operability; Dana accepts business authorities. No single signoff substitutes for the others.

**Open item:** exact availability exclusions, service credits, and incident-notification wording remain commercial issues. Sales summaries must keep them marked proposed until agreement.

## Related records

- [EF-012: Solution architecture decision record: request workflow beside the ERP](../02_solution_design/12_solution-architecture.md)
- [EF-014: Security intake: evidence requested and statements not yet accepted](../02_solution_design/14_security-questionnaire.md)
- [EF-022: Pilot test plan and evidence register](../03_validation/22_pilot-test-plan.md)
- [EF-035: Security closure record: pilot conditions resolved with production controls](../04_commercial/35_security-closure-record.md)
