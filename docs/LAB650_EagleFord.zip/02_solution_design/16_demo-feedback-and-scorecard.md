---
document_id: EF-016
account: EagleFord
document_date: 2026-04-06
document_type: "Customer feedback summary"
stage: "Solution validation"
author: "Jo Ellis, Procurement Operations Analyst"
participants: "Jo Ellis; Dana Brooks; Caleb Turner; Owen Park; Rowan Patel"
synthetic: true
---

# Demo feedback and revised evaluation scorecard

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Feedback collection

Jo collected feedback individually before the group debrief to avoid turning the loudest opinion into a consensus. Scores below are workshop judgments on a five-point scale, not statistical survey results. A high score is not a passed acceptance test.

| Dimension | Weight | Current score | Reason |
|---|---:|---:|---|
| Requester usability | 25% | 4 | Shorter intake, but weak-signal recovery needs testing |
| Approval transparency | 20% | 4 | States are understandable; delegation remains conditional |
| Integration reliability | 25% | 2 | Design is credible, implementation unproven |
| Control and auditability | 20% | 3 | Good event model; retention/export review open |
| Administration effort | 10% | 3 | Configuration looks manageable; handoff not demonstrated |

The weighted score is 3.2 out of 5. Jo explicitly rejected rounding it to “80% fit.” Mandatory requirements remain gates even if other dimensions score well.

## What users liked

Caleb preferred clear state messages to the legacy habit of asking procurement for updates. Dana liked the ability to see who owns an exception. Owen appreciated the distinction between an approved request and an issued PO.

The demonstration's failure path generated more useful discussion than the routine path. The team wants an evaluation that recreates realistic faults, including duplicate callbacks, expired delegation, and a retired cost center.

## What could block adoption

The text-draft message must remain visible after a failed upload. Training cannot imply that photographs are retained offline. Procurement will need a short field guide explaining when users should contact a person rather than retry repeatedly.

Jo also noted that administrators can create confusing report filters even when the underlying events are correct. A standard pilot dashboard should be locked to documented definitions, with a separate exploratory view.

## Changes to evaluation

The pilot scorecard will include explicit red-line conditions: unauthorized cross-location visibility, duplicate purchase orders caused by replay, and untraceable approval history. Any confirmed occurrence pauses evaluation until contained and reviewed.

Delegation expiry and audit export may be conditionally accepted for pilot close only if there is an approved operating control, an owner, and a production gate. “On the roadmap” is not an acceptable disposition.

## Next actions

Rowan and Owen will finish nonfunctional requirements. Dana will nominate approvers from both pilot locations. Avery will prepare a mutual action plan that includes a no-go outcome if the evidence fails.

**Customer position:** continue evaluation. No preference award, pilot purchase, or funding commitment was made in this meeting.

## Related records

- [EF-015: Demonstration transcript: show the broken path](../02_solution_design/15_demonstration-transcript.md)
- [EF-017: Nonfunctional requirements and production-readiness gates](../02_solution_design/17_nonfunctional-requirements.md)
- [EF-020: Mutual action plan: evidence gates through a possible purchase](../02_solution_design/20_mutual-action-plan.md)
- [EF-022: Pilot test plan and evidence register](../03_validation/22_pilot-test-plan.md)
