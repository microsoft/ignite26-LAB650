---
document_id: EF-020
account: EagleFord
document_date: 2026-04-21
document_type: "Joint evaluation plan"
stage: "Evaluation planning"
author: "Avery Stone and Tessa Grant"
participants: "Dana Brooks; Tessa Grant; Owen Park; Avery Stone; Rowan Patel; Marcus Bell"
synthetic: true
---

# Mutual action plan: evidence gates through a possible purchase

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Purpose

This plan aligns the work required for a decision. It does not obligate EagleFord to purchase and does not guarantee a September signature. The customer may stop after any gate if fit, risk, or economics are unacceptable.

| Gate | Working date | Customer accountable | Seller accountable | Exit evidence |
|---|---|---|---|---|
| Pilot scope and paid authorization | May 1 | Dana / procurement | Avery / Marcus | Signed bounded pilot scope |
| Test plan and security permission | May 20 | Owen / Simone | Rowan / Grace | Approved tests and data rules |
| Pilot start | June 1 | Tessa | Marcus | Trained users and working environment |
| Midpoint review | June 12 | Dana | Rowan | Evidence quality and risk review |
| Pilot close | July 10 | Jo / Owen | Rowan | Metrics, defect log, UAT disposition |
| Sponsor readout | July 16 | Luis | Avery | Operational go/no-go |
| Financial review | July 30 | Maya, attendance to confirm | Avery / Quinn | Credible base and downside case |
| Procurement and legal | August–September | Erin / procurement | Noah / Avery | Approved terms and scope |
| Potential signature | September 25 | Authorized signatory | Quinn | Executed agreement |

## Decision process confirmed

Dana coordinates evaluation. Luis owns the operational recommendation. Priya can reject the architecture. Simone owns security acceptance. Maya must approve recurring spend and implementation funding. Erin manages contractual review with procurement.

No single enthusiastic meeting overrides these roles. The team will ask for explicit signoff at each gate and retain the evidence in the shared decision log.

## Resource commitments

EagleFord will provide two pilot locations, forty proposed named users, a business administrator, and integration ownership. Northstar will provide a solutions engineer and a professional-services lead. Actual participation remains subject to scheduling and the pilot scope.

The working pilot fee is $18,000. Whether and how that fee is credited toward later implementation must be stated in the pilot agreement. It is not free evaluation labor.

## Pause and exit conditions

The pilot will pause for a transaction-integrity issue, unauthorized access, or loss of reliable approval evidence. A failed economic case may result in no purchase even if technical testing succeeds.

If the teams cannot complete security review before realistic data is required, the schedule moves. The plan does not authorize loading data early.

## Communications

Weekly operational check-ins will use a short decision-and-blocker format. Tessa owns the customer action log; Avery owns seller follow-through. Executive escalation goes through Dana and Luis rather than bypassing them.

**Immediate actions:** Marcus drafts scope; Owen reserves integration capacity; Simone identifies pilot security prerequisites. The September date stays a planning assumption until the gates support it.

## Related records

- [EF-019: Evaluation risk register and unresolved dependencies](../02_solution_design/19_evaluation-risk-register.md)
- [EF-021: Pilot statement of work: two locations, bounded evidence](../03_validation/21_pilot-statement-of-work.md)
- [EF-030: Sponsor readout transcript: a recommendation is not funding](../03_validation/30_sponsor-readout-transcript.md)
- [EF-040: Executed agreement summary and order reconciliation](../04_commercial/40_executed-agreement-summary.md)
