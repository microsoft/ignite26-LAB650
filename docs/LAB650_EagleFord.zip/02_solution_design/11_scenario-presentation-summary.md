---
document_id: EF-011
account: EagleFord
document_date: 2026-03-17
document_type: "Presentation summary"
stage: "Solution validation"
author: "Rowan Patel, Solutions Engineer"
participants: "Dana Brooks; Caleb Turner; Owen Park; Jo Ellis; Avery Stone; Rowan Patel"
synthetic: true
---

# Presentation summary: one request, four distinct states

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Presentation purpose

The six-slide session used the replacement pump-seal scenario from discovery. The goal was to validate the proposed operating model before building a detailed demonstration. All screenshots and transaction values were invented.

## Slide-by-slide record

**Slide 1 — The requester's view.** A supervisor selects North Mesa, identifies an asset, and explains the operational need. The form accepts a description and image without requiring an exact supplier part number. Caleb approved the shorter entry path but asked for a visible indication that an image is still uploading.

**Slide 2 — Completeness without false certainty.** Required location and cost-center references are validated against customer-provided data. Procurement can request clarification without deleting the original submission time. Dana rejected the label “invalid request” for ordinary clarification; it should describe what is missing.

**Slide 3 — Approval is a decision, not a purchase order.** Four distinct states appear: submitted, awaiting approval, approved/ERP processing, and PO issued. Owen requested an additional failure state with an owner and retry history. A green “approved” badge must not imply that the supplier can accept an order.

**Slide 4 — Controlled urgency.** Emergency requests show an operational justification and a reference to EagleFord's escalation policy. Miguel's safety-authorization boundary was included explicitly even though he could not attend.

**Slide 5 — Visibility by role.** Requesters see their requests; procurement sees authorized location queues; administrators manage configuration but do not inherit financial approval authority. Owen asked for a demonstration of a cross-location access denial.

**Slide 6 — Measurement.** The proposed dashboard separates end-to-end elapsed time, handling effort, emergency share, and integration exceptions. Jo asked that open cohorts appear beside completed-request statistics.

## Reactions and changes

The strongest reaction was to state transparency, not analytics. Caleb said a clear failed-submission message would be more valuable than a polished dashboard. Dana emphasized delegation and ownership during absences. Owen questioned whether retry behavior was designed or merely illustrated.

## Decisions

- Proceed to architecture design with the four-state model plus explicit failure handling.
- Build the demonstration around routine, emergency, and failed-integration paths.
- Do not use the presentation as evidence that the actual integration is complete.
- Keep “supplier stock confirmation” outside the workflow promise.

## Follow-up

Rowan owns a revised state diagram by March 20. Owen will provide the middleware interface constraints. Dana will review sample authority rules. Avery will ask the customer to score the demonstration against agreed requirements rather than overall presentation quality.

## Related records

- [EF-009: FieldBridge RFI response and explicit capability gaps](../01_discovery/09_rfi-response.md)
- [EF-012: Solution architecture decision record: request workflow beside the ERP](../02_solution_design/12_solution-architecture.md)
- [EF-015: Demonstration transcript: show the broken path](../02_solution_design/15_demonstration-transcript.md)
- [EF-016: Demo feedback and revised evaluation scorecard](../02_solution_design/16_demo-feedback-and-scorecard.md)
