---
document_id: EF-013
account: EagleFord
document_date: 2026-03-24
document_type: "Technical workshop and mapping specification"
stage: "Solution validation"
author: "Rowan Patel, Solutions Engineer"
participants: "Owen Park; Jo Ellis; Dana Brooks; Rowan Patel; Marcus Bell"
synthetic: true
---

# Integration mapping workshop: fields, states, and replay rules

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Mapping decisions

The integration exchanges approved purchase-request data, not invoices. All sample identifiers below are synthetic. Request values used in tests are examples and do not establish EagleFord's spending authorities.

| FieldBridge field | Integration treatment | Dynamics destination or use |
|---|---|---|
| request_id | Immutable business key | External request reference |
| approval_version | Increment when an approved request is materially changed | Replay/conflict control |
| location_code | Validate against active location list | Delivery and financial context |
| cost_center | Validate against current master data | Financial dimension |
| asset_reference | Optional structured reference | Supporting purchase description |
| requested_description | Preserve approved text | PO line description |
| estimated_value | Planning input, not final supplier commitment | Validation and routing context |
| emergency_flag | Preserve policy classification | Reporting and exception evidence |
| authorized_approver | Resolve to customer identity | Approval evidence |
| idempotency_key | Stable across transport retries | Duplicate prevention |

## State contract

An HTTP acknowledgment means the integration received the payload. It does not mean Dynamics issued a PO. The final callback must carry either a validated PO identifier or a failure status with a correlation ID. FieldBridge cannot infer “PO issued” from elapsed time.

Material changes after approval return the request to the required approval step. Cosmetic description corrections may follow a narrower rule, but Dana must approve that distinction. Changing cost center or financial amount is never treated as cosmetic.

## Discussion highlights

Owen raised the possibility of a callback arriving twice after a timeout. Rowan confirmed the consumer should be idempotent as well as the sender. Marcus proposed a test where Dynamics accepts the transaction but the response is deliberately dropped.

Jo requested consistent timestamps for submission, initial approval, final approval, integration receipt, and PO issuance. Reopened requests must preserve the earlier events rather than overwrite history.

Dana asked whether the vendor could “repair” a retired cost center. The answer was no: the customer must select an active, authorized reference.

## Error ownership

- Invalid reference data: procurement administrator, with Owen notified.
- Identity mismatch: customer identity administrator.
- ERP rejection: EagleFord integration operations.
- FieldBridge payload defect: Northstar support.
- Ambiguous success after timeout: integration operations checks the stable business key before replay.

## Deliverables and open item

Marcus will supply a versioned payload example and test harness. Owen will provide a nonproduction endpoint after security approval. Jo will maintain a reconciliation sheet during the pilot.

The maximum attachment size is not finalized. Images will remain in FieldBridge with authorized access, not be copied indiscriminately into ERP notes. This decision reduces unnecessary replication and must be included in the security review.

## Related records

- [EF-012: Solution architecture decision record: request workflow beside the ERP](../02_solution_design/12_solution-architecture.md)
- [EF-014: Security intake: evidence requested and statements not yet accepted](../02_solution_design/14_security-questionnaire.md)
- [EF-022: Pilot test plan and evidence register](../03_validation/22_pilot-test-plan.md)
- [EF-027: Pilot incident report: duplicate callbacks without duplicate purchase orders](../03_validation/27_pilot-integration-incident.md)
