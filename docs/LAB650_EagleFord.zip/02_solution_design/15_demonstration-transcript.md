---
document_id: EF-015
account: EagleFord
document_date: 2026-04-02
document_type: "Demonstration transcript"
stage: "Solution validation"
author: "Rowan Patel, Solutions Engineer"
participants: "Dana Brooks; Caleb Turner; Owen Park; Jo Ellis; Avery Stone; Rowan Patel"
synthetic: true
---

# Demonstration transcript: show the broken path

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Session context

The demonstration used a configured sandbox and a simulated Dynamics interface. No live purchase orders were created. Rowan distinguished product behavior from simulated integration responses at the start of the session.

## Transcript excerpts

**[00:04] Rowan:** Caleb's supervisor persona creates a replacement request. The part number is optional. Location and cost center are validated.

**[00:07] Caleb:** The upload indicator helps. What happens if I leave before it finishes?

**[00:08] Rowan:** The request is not submitted until the server confirms receipt. Let me interrupt the network rather than describe the answer.

**[00:10] Caleb:** That message says the text draft is saved but the attachment is not sent. That is clearer. I still want the draft warning to remain visible when I return.

**[00:16] Dana:** Show me an approver who is on leave.

**[00:18] Rowan:** This delegation expires on the date shown. We need to test whether a requester can accidentally become their own delegate approver. That is not signed off yet.

**[00:24] Owen:** Now approve it and drop the ERP response.

**[00:26] Rowan:** The approval is recorded. The next state is ERP processing, not PO issued. This simulated timeout goes to the exception queue.

**[00:28] Owen:** What stops a second purchase order when someone clicks retry?

**[00:29] Rowan:** The intended design uses the same business key and checks the ERP outcome before replay. The actual middleware implementation still needs testing. This sandbox does not prove that integration.

**[00:34] Jo:** The dashboard shows only completed requests in the median. Where are open ones?

**[00:35] Rowan:** The open-cohort panel is below. We should place it beside the median so nobody misses the cutoff effect.

**[00:41] Dana:** I prefer that you showed the limitation. I am not approving the pilot until Owen has a test plan.

## Demonstrated evidence

Mobile request creation, explicit failed-upload messaging, approval-state visibility, location-scoped user views, and a configurable exception queue were shown. Integration resilience, production identity configuration, and independent audit retention remain unproven.

## Customer requests

- Keep the unsent-draft warning persistent.
- Place open-cohort counts beside completed timing metrics.
- Demonstrate self-approval prevention with an expiring delegate.
- Test an ERP acceptance followed by a lost callback.

## Follow-up commitments

Rowan will send a demonstration evidence matrix by April 6. Owen will coauthor integration tests. Avery will not describe the session as technical approval in the forecast.

**Evaluation signal:** engagement is strong, but the buyer's emphasis has shifted from interface quality to reliable operational ownership.

## Related records

- [EF-011: Presentation summary: one request, four distinct states](../02_solution_design/11_scenario-presentation-summary.md)
- [EF-016: Demo feedback and revised evaluation scorecard](../02_solution_design/16_demo-feedback-and-scorecard.md)
- [EF-022: Pilot test plan and evidence register](../03_validation/22_pilot-test-plan.md)
- [EF-027: Pilot incident report: duplicate callbacks without duplicate purchase orders](../03_validation/27_pilot-integration-incident.md)
