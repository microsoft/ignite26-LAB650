---
document_id: EF-019
account: EagleFord
document_date: 2026-04-17
document_type: "Risk register"
stage: "Evaluation planning"
author: "Tessa Grant, Transformation PM"
participants: "Tessa Grant; Dana Brooks; Owen Park; Avery Stone; Marcus Bell"
synthetic: true
---

# Evaluation risk register and unresolved dependencies

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Risk review principles

The register tracks risks to a useful evaluation, not only risks to a sales close. Owners must state the next evidence needed and a date. A mitigation is not complete because somebody has scheduled a meeting.

| ID | Risk | Likelihood / impact | Mitigation and owner |
|---|---|---|---|
| RK-01 | Integration engineer unavailable during pilot preparation | High / High | Owen confirms named coverage before scope approval |
| RK-02 | Weak connectivity causes users to assume a draft was sent | Medium / High | Caleb validates messaging; Rowan tests failure paths |
| RK-03 | Audit-export retention not accepted | Medium / High | Grace and Simone agree pilot and production controls |
| RK-04 | Baseline selection makes improvement look better than it is | Medium / Medium | Jo fixes definitions and reports open cohort |
| RK-05 | Summer maintenance reduces user participation | High / Medium | Tessa reserves sessions and backup evaluators |
| RK-06 | Delegation permits self-approval | Low / High | Dana approves conflict tests and fallback control |
| RK-07 | Business case treats capacity as cash savings | Medium / High | Avery labels categories; CFO reviews later |
| RK-08 | Realistic data loaded before security permission | Low / High | Simone's written gate required |

## Discussion

Tessa challenged the assumption that a June pilot is automatically convenient. North Mesa has maintenance work in the same period. Caleb can nominate users, but operations cannot guarantee that every scheduled tester will attend.

Marcus proposed a smaller workflow scope rather than compressing training. Owen preferred two request types integrated reliably to five request types supported by a temporary script nobody can maintain.

Dana asked that the risk register be shared with the customer, including sales-owned risks. “If the financial story does not work, that is an evaluation finding too.”

## Dependency decisions

The pilot start will be contingent on a working nonproduction interface, approved test data, trained participants, and a clear rollback path. Missing an internal vendor target does not justify bypassing these gates.

The initial test cohort will include both comfortable and hesitant users. Selecting only power users would obscure adoption risk. Open requests and abandoned attempts must remain visible in reporting.

## Escalation rule

Suspected unauthorized data access, a duplicate financial transaction, or loss of approval evidence pauses the relevant testing path immediately. The team will preserve evidence, contain the issue, and decide whether the pilot can continue. Vendor sales personnel cannot overrule that pause.

## Next review

Tessa will review the register with both teams on April 21. Owners may downgrade a risk only when the supporting evidence is linked. Risks can be accepted with a documented operating control; they cannot be closed by changing their label.

## Related records

- [EF-017: Nonfunctional requirements and production-readiness gates](../02_solution_design/17_nonfunctional-requirements.md)
- [EF-020: Mutual action plan: evidence gates through a possible purchase](../02_solution_design/20_mutual-action-plan.md)
- [EF-021: Pilot statement of work: two locations, bounded evidence](../03_validation/21_pilot-statement-of-work.md)
- [EF-027: Pilot incident report: duplicate callbacks without duplicate purchase orders](../03_validation/27_pilot-integration-incident.md)
