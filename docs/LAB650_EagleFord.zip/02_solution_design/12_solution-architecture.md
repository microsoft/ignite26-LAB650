---
document_id: EF-012
account: EagleFord
document_date: 2026-03-20
document_type: "Architecture decision record"
stage: "Solution validation"
author: "Owen Park, Enterprise Applications Manager"
participants: "Owen Park; Priya Nair; Rowan Patel; Marcus Bell"
synthetic: true
---

# Solution architecture decision record: request workflow beside the ERP

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Decision ADR-01

Use FieldBridge for request intake, approval coordination, and request-event history. Retain Dynamics 365 Finance as the system of record for purchase orders and financial coding. Route transactional integration through EagleFord's Azure integration layer.

**Status:** accepted for detailed pilot design, subject to security review and proof of failure recovery. This is not a production architecture authorization.

## Logical flow

```text
Field user -> FieldBridge request -> EagleFord approval rules
                                      |
                               approved payload
                                      v
                           Azure integration layer
                                      |
                         Dynamics validated interface
                                      |
                           PO number / failure code
                                      v
                        FieldBridge requester status
```

Entra ID supplies authentication. Location, asset reference, and cost-center data originate from EagleFord-controlled sources. FieldBridge stores the approved request and correlation identifiers; it must not become a competing financial master.

## Interface responsibilities

| Component | Owner | Responsibility |
|---|---|---|
| FieldBridge configuration | Northstar during pilot, customer-admin handoff later | Forms, workflow rules, role mapping |
| Integration layer | Owen | Validation, retries, ERP invocation, operational alerts |
| Dynamics configuration | EagleFord ERP team | Purchase-order rules and master data |
| Identity groups | EagleFord identity team | Group ownership and access lifecycle |
| Cross-system evidence | Jo and Owen | Reconcile request IDs with ERP outcome |

## Alternatives considered

**Direct database integration** was rejected because it bypasses supported ERP controls and creates a maintenance burden. **Replacing Dynamics purchasing** was rejected because the business problem does not justify replacing the financial system. **A reporting-only overlay** may reduce status calls but would not address incomplete intake.

## Failure semantics

Each approved request receives a stable idempotency key before transmission. A timeout does not imply failure or success. Before replay, the integration checks whether Dynamics already accepted the key. Retries must not generate a fresh business identifier.

An exception queue exposes the failure reason and named operational owner. Requesters receive a neutral “processing issue” state, not raw system details. Northstar support cannot unilaterally change financial references to clear a queue.

## Open decisions

Reference-data refresh frequency, audit-export retention, nonproduction data handling, and support coverage still require review. The design assumes online submission. Text draft recovery is a user-experience safeguard, not an offline transaction guarantee.

**Approval gate:** Owen must witness duplicate-prevention and recovery tests. Priya will not authorize production simply because a happy-path demonstration succeeds.

## Related records

- [EF-008: Requirements workshop: must-haves, exclusions, and ownership](../01_discovery/08_requirements-workshop.md)
- [EF-013: Integration mapping workshop: fields, states, and replay rules](../02_solution_design/13_integration-mapping.md)
- [EF-017: Nonfunctional requirements and production-readiness gates](../02_solution_design/17_nonfunctional-requirements.md)
- [EF-027: Pilot incident report: duplicate callbacks without duplicate purchase orders](../03_validation/27_pilot-integration-incident.md)
