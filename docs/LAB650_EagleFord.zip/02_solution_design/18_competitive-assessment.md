---
document_id: EF-018
account: EagleFord
document_date: 2026-04-14
document_type: "Internal competitive assessment"
stage: "Evaluation planning"
author: "Avery Stone, Account Executive"
participants: "Avery Stone; Rowan Patel; Quinn Foster"
synthetic: true
---

# Competitive assessment: a new platform is not the only option

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Options disclosed by the customer

Dana confirmed three paths under consideration. The alternatives below are fictional and described only to frame the simulation. We have no competitor contract, confidential competitor pricing, or verified access to another vendor's roadmap.

| Option | Perceived strength | Risk or unanswered question |
|---|---|---|
| FieldBridge by Northstar | Purpose-built intake, explicit state visibility | New integration and subscription expense |
| ProcureTrail | Broad catalog and supplier content | Customer has not validated field usability or integration ownership |
| Extend existing Microsoft tooling | Familiar environment and existing skills | Support burden and unclear end-to-end transaction controls |
| Keep current process | No acquisition project | Ongoing rework and low visibility |

## What actually matters

The customer is not buying the highest feature count. Priya is evaluating operational supportability. Caleb is evaluating whether a request can be entered without abandoning the physical job. Maya has not yet joined but is likely to challenge whether capacity value translates into spend reduction.

Our differentiator should be demonstrated accountability across submission, approval, and PO issuance. Claiming we are “the only integrated option” would be unsupported. EagleFord can choose to build an integration; the question is cost, ownership, and evidence.

## Likely objections and responsible responses

**“We already own tools that can build forms.”** Agree. Ask who will own exception recovery, versioned approval rules, and support. Do not disparage customer engineers.

**“The catalog vendor includes more functionality.”** Acknowledge it. Reconfirm whether catalogs and invoice automation solve the current first-phase problem. If those become mandatory, reassess fit.

**“We can save money by doing nothing.”** Compare the cost of a new system with the actual burden of the existing process. Avoid treating every minute of current effort as avoidable cash expense.

## Sales risks

The strongest alternative may be no decision rather than ProcureTrail. The summer maintenance window could reduce implementation capacity instead of accelerate purchasing. A technically successful pilot could still fail the financial gate.

Do not counter with an unapproved discount. First discover which requirement or economic assumption changes the decision. Any commercial offer must identify scope, duration, and corresponding customer commitments.

## Action plan

Avery will ask Dana how options will be scored and whether a formal procurement process applies. Rowan will emphasize evidence on replay behavior and role restrictions. Quinn will review resource availability before agreeing to a pilot schedule.

**Forecast treatment:** remain in evaluation planning. Competitive engagement is a reason to sharpen proof, not a basis for a higher probability by itself.

## Related records

- [EF-016: Demo feedback and revised evaluation scorecard](../02_solution_design/16_demo-feedback-and-scorecard.md)
- [EF-020: Mutual action plan: evidence gates through a possible purchase](../02_solution_design/20_mutual-action-plan.md)
- [EF-031: Business case: a thin first-year base case, not guaranteed cash savings](../04_commercial/31_business-case-model.md)
- [EF-037: Commercial negotiation transcript: discount, scope, and implementation risk](../04_commercial/37_commercial-negotiation-transcript.md)
