---
document_id: EF-014
account: EagleFord
document_date: 2026-03-27
document_type: "Security questionnaire response and gap log"
stage: "Security review"
author: "Grace Liu, Security Assurance Lead"
participants: "Simone Reed; Grace Liu; Owen Park; Rowan Patel"
synthetic: true
---

# Security intake: evidence requested and statements not yet accepted

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Review status

Simone received Northstar's fictional security packet through the designated review channel. This document records review questions and proposed controls. It does not assert a real certification, attach a real audit report, or constitute EagleFord's security approval.

## Initial review matrix

| Control area | Proposed treatment | Customer disposition |
|---|---|---|
| Authentication | Entra ID SSO, customer-managed conditional access | Acceptable in principle; test required |
| Authorization | Role and location scopes | Require negative-access tests |
| Hosting | US production region | Confirm contractual region restriction |
| Encryption | Encryption in transit and at rest | Evidence requested |
| Auditability | Actor, event, timestamp, request ID, rule version | Export and retention design incomplete |
| Incident notification | Contractual process | Legal wording open |
| Support access | Time-bound access with logged justification | Require review and customer approval procedure |
| Data deletion | Export followed by deletion workflow | Timing and backup treatment open |
| Subprocessors | Maintained list and change notification | Counsel review required |

## Key questions from Simone

“Who can access a request image during a support case?”  
“Can a location administrator see another location's operational requests?”  
“Does deleting an account remove the audit evidence of past approvals?”  
“How do we distinguish your availability target from a binding service commitment?”

Grace clarified that disabling a user must not erase the identity associated with historic approval events. A support engineer should not obtain standing business-user access. Evidence requests will be answered through the review process, not by inserting unreviewed claims into a sales deck.

## Data minimization

The evaluation does not require banking information, payment-card information, health records, government identifiers, or detailed safety incidents. Users must avoid photographing badges, computer screens, or bystanders when attaching equipment images.

Pilot data will be restricted to approved operational fields after security authorization. Earlier demonstrations will continue to use invented data. Northstar will not request a production ERP database extract.

## Gaps and owners

Grace owns the audit-export sample and support-access procedure. Owen owns the customer log-destination requirements. Simone owns acceptance of retention and event fields. Noah Evans and Erin Walsh will negotiate contractual security terms if the evaluation proceeds.

## Pilot gate

The pilot cannot begin with realistic customer data until identity, scope restrictions, and audit evidence are accepted for that bounded use. An enterprise production review will still be required before rollout.

**Material unresolved issue:** whether EagleFord can retain exported audit records independently for its required period. The sales team must not mark R-05 fully met until that solution is documented and accepted.

## Related records

- [EF-009: FieldBridge RFI response and explicit capability gaps](../01_discovery/09_rfi-response.md)
- [EF-013: Integration mapping workshop: fields, states, and replay rules](../02_solution_design/13_integration-mapping.md)
- [EF-017: Nonfunctional requirements and production-readiness gates](../02_solution_design/17_nonfunctional-requirements.md)
- [EF-035: Security closure record: pilot conditions resolved with production controls](../04_commercial/35_security-closure-record.md)
