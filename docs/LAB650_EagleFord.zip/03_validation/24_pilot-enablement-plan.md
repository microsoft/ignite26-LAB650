---
document_id: EF-024
account: EagleFord
document_date: 2026-05-20
document_type: "Training and change plan"
stage: "Pilot preparation"
author: "Tessa Grant, Transformation PM"
participants: "Tessa Grant; Caleb Turner; Dana Brooks; Marcus Bell; Rowan Patel"
synthetic: true
---

# Pilot enablement plan: teach the exception, not just the form

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Audience and sequence

Forty pilot users will be trained in three groups: field requesters, approvers, and procurement administrators. Training attendance is not the same as active adoption. Tessa will record attendance separately from completed first requests.

| Audience | Format | Evidence of readiness |
|---|---|---|
| Requesters | Two 30-minute small-group sessions | Submit a sample request and interpret an unsent state |
| Approvers | 45-minute scenario workshop | Approve, reject, request clarification, identify delegation limits |
| Administrators | 90-minute supervised lab | Resolve a reference error and escalate an ambiguous ERP outcome |

## Learning objectives

A requester should know the difference between a saved text draft, a submitted request, an approved request, and an issued PO. The session intentionally includes a failed attachment upload. Caleb will demonstrate that the correct response is to follow the unsent-state guidance, not assume procurement has received the image.

Approvers will practice reading the original justification and checking conflicts. Delegation is not a convenience feature that overrides self-approval restrictions. Where automated expiry is not yet accepted, procurement will use a documented substitute-approver control.

Administrators will practice escalating an ERP timeout without creating a new business request. Only the designated integration operator may replay an ambiguous transaction after checking the business key.

## Change message

The pilot is intended to reduce uncertainty, not monitor individual workers. Jo will report process-level metrics. Individual request timestamps should not be repurposed as employee productivity rankings.

The old route remains available as a controlled fallback during pilot incidents. Users must record fallback requests for reconciliation rather than double-enter them in both systems.

## Questions collected

- Can a supervisor submit for a colleague? Only under an approved role; not by sharing credentials.
- Does the emergency flag approve a safety exception? No.
- Can a request proceed without a part number? Yes, with an adequate description and required financial references.
- Does a saved draft retain images offline? No guarantee; the warning must say what remains unsent.

## Readiness gaps

Four scheduled users are on rotating shifts. Tessa will arrange make-up sessions rather than count them as trained. The session plan has forty intended users but must track actual completion.

## Owners and follow-up

Marcus will deliver the labs. Caleb and a Red Creek supervisor will collect field questions. Dana will approve the one-page escalation guide. Rowan will answer product questions but not improvise customer purchasing policy.

**Pilot-start condition:** each active participant has the appropriate training and access; no user is activated simply to complete a roster count.

## Related records

- [EF-006: North Mesa field observation: the five-minute request](../01_discovery/06_north-mesa-field-observation.md)
- [EF-021: Pilot statement of work: two locations, bounded evidence](../03_validation/21_pilot-statement-of-work.md)
- [EF-025: Pilot kickoff transcript: what success does and does not mean](../03_validation/25_pilot-kickoff-transcript.md)
- [EF-043: Training clinic: real user questions and corrected assumptions](../05_delivery/43_training-questions-and-field-guide.md)
