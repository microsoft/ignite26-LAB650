---
document_id: EF-028
account: EagleFord
document_date: 2026-06-23
document_type: "Retest record and operating decision"
stage: "Pilot execution"
author: "Marcus Bell, Professional Services Lead"
participants: "Marcus Bell; Owen Park; Simone Reed; Dana Brooks; Rowan Patel"
synthetic: true
---

# Corrective-action review: controlled replay and remaining pilot conditions

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Retest scope

The team retested callback duplication, worker restart after timeout, ERP acceptance with lost response, and manual replay. The patch preserves callback correlation and suppresses repeated status events without changing the original financial business key.

The exercise used approved pilot test records. It did not create supplier commitments. Owen retained the before-and-after event trails and reconciliation evidence.

## Results

| Recovery case | Outcome | Reviewer |
|---|---|---|
| Duplicate callback delivered twice | Second callback ignored; event logged | Owen |
| Worker restart during timeout | Existing correlation recovered | Owen |
| ERP accepts, response lost | ERP lookup finds existing PO; no new PO | Owen / Rowan |
| Operator attempts unauthorized replay | Action denied and logged | Simone |
| Valid operator replays unresolved transport message | Existing business key retained | Owen |

T18 is marked passed after retest, with the original June 18 failure retained. The seven affected live pilot requests have been reconciled. The measured disruption remains in the final narrative.

## Decision

Dana and Owen approved resumption of the affected automation with supervised monitoring. The pause did not invalidate the entire evaluation, but it changed the readiness requirements. A restart scenario is now mandatory before each meaningful integration release.

## Remaining conditions

**T13 — Delegation expiry.** The current pilot uses an approved substitute-approver record plus a daily expiry check. This prevents a standing delegation from being assumed indefinitely, but it depends on an operator. Production needs an automated expiry control or an accepted equivalent with clear ownership.

**T22 — Audit-export retention.** Reviewed export files are available, but scheduled delivery, destination immutability, and failure alerting are not fully proven. Simone accepts the supervised pilot treatment only. Seven-year independent retention remains a production requirement.

## Support model lesson

The issue was resolved while Owen, Marcus, and Rowan were all available. The final service model must identify who can reconcile a transaction outside a workshop. The runbook will include the business key, expected state, evidence location, authorized operator, and escalation route.

## Customer communication

Tessa will brief the two site coordinators. The message should be specific: status updates were unreliable for a short period; existing PO controls prevented duplicate financial creation in the reviewed records; operators reconciled affected requests. Avoid “nothing happened” and avoid suggesting a wider outage than the evidence supports.

**Next action:** include retest evidence and the two residual conditions in the July 10 pilot report. Neither condition is silently waived by resuming testing.

## Related records

- [EF-027: Pilot incident report: duplicate callbacks without duplicate purchase orders](../03_validation/27_pilot-integration-incident.md)
- [EF-029: Pilot results: measurable progress with two conditional acceptance cases](../03_validation/29_pilot-results-report.md)
- [EF-035: Security closure record: pilot conditions resolved with production controls](../04_commercial/35_security-closure-record.md)
- [EF-041: Sales-to-success handoff: promises, limitations, and the customer narrative](../05_delivery/41_sales-to-success-handoff.md)
