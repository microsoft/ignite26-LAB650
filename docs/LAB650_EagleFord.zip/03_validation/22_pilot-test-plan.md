---
document_id: EF-022
account: EagleFord
document_date: 2026-05-06
document_type: "Acceptance test plan"
stage: "Pilot preparation"
author: "Owen Park, Enterprise Applications Manager"
participants: "Owen Park; Rowan Patel; Jo Ellis; Simone Reed; Caleb Turner"
synthetic: true
---

# Pilot test plan and evidence register

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Testing model

The acceptance register contains **24 scenarios** across intake, identity, approvals, integration, audit, and reporting. Passing a scenario requires observed evidence and an owner signoff. A screen recording of a happy path is insufficient for a negative or recovery test.

## Scenario inventory

| Group | Cases | Representative evidence |
|---|---:|---|
| Intake and connectivity | T01–T05 | Submit, missing fields, failed upload, draft recovery, duplicate click |
| Identity and authorization | T06–T09 | SSO, disabled user, cross-location denial, administrator boundaries |
| Approval controls | T10–T14 | Correct route, rejection, material change, delegation, self-approval prevention |
| Integration integrity | T15–T19 | Valid PO, bad reference, lost callback, replay, exception ownership |
| Audit and reporting | T20–T24 | Actor history, export, retention handoff, metric reconciliation, open-cohort reporting |

T13 covers delegation expiry. T22 covers scheduled audit export and independent retention. These are known candidates for conditional disposition if the pilot operating controls are adequate; production still requires closure or an explicitly approved equivalent.

## Fault-injection procedure

For T17, allow Dynamics to accept a request, suppress the callback, and verify that the UI remains in processing. For T18, replay the same business request using the stable idempotency key and verify that no additional PO is created.

Operators must record the FieldBridge request ID, transport correlation ID, ERP reference, expected state, actual state, and resolution. A test failure must remain in the register even after a later retest passes.

## Metrics

The pilot will count every submitted request. At the close cutoff, completed requests contribute to completed-cohort cycle time; open requests remain separately visible. No open request receives a zero-duration completion. Jo will reconcile totals before results are presented to Luis.

Handling effort will use paired observations where feasible, not an estimate derived from end-to-end elapsed days. Emergency classification follows Dana's policy.

## Safety and privacy

No safety-permit process is tested as an automated authorization. Use approved, minimal operational data. Stop testing if unauthorized cross-location visibility or a duplicate financial transaction is suspected.

## Signoff

Caleb accepts requester behavior. Dana accepts authorities. Owen accepts integrity and operability. Simone accepts audit and access controls. A conditional case requires a written limitation, an owner, a due date, and an explicit production gate.

**Schedule dependency:** testing begins only after the nonproduction endpoint and approved data set are available. Compressed preparation is not a reason to remove negative tests.

## Related records

- [EF-017: Nonfunctional requirements and production-readiness gates](../02_solution_design/17_nonfunctional-requirements.md)
- [EF-021: Pilot statement of work: two locations, bounded evidence](../03_validation/21_pilot-statement-of-work.md)
- [EF-023: Data-readiness findings: retired cost centers and ambiguous locations](../03_validation/23_data-readiness-findings.md)
- [EF-027: Pilot incident report: duplicate callbacks without duplicate purchase orders](../03_validation/27_pilot-integration-incident.md)
- [EF-029: Pilot results: measurable progress with two conditional acceptance cases](../03_validation/29_pilot-results-report.md)
