---
document_id: EF-021
account: EagleFord
document_date: 2026-05-01
document_type: "Pilot scope and commercial summary"
stage: "Pilot authorization"
author: "Marcus Bell, Professional Services Lead"
participants: "Dana Brooks; Tessa Grant; Owen Park; Marcus Bell; Avery Stone"
synthetic: true
---

# Pilot statement of work: two locations, bounded evidence

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Authorized evaluation

EagleFord authorizes a paid FieldBridge pilot at **North Mesa and Red Creek**, with **40 named users** across requesters, approvers, and administrators. The planned operating window is **June 1–July 10, 2026**. Preparation and training precede that window.

The pilot evaluates maintenance-material requests and simple service requests. Capital-project purchasing, invoice automation, supplier onboarding, and safety-permit workflows are excluded. The forty pilot users are a subset of a potential enterprise population, not an additional license population.

## Deliverables

| Workstream | Deliverable | Accountable owner |
|---|---|---|
| Workflow | Two request templates and approved routing | Dana / Marcus |
| Identity | Entra ID group mapping and role tests | Owen / Rowan |
| Integration | Approved-request handoff and PO callback | Owen |
| Measurement | Baseline definitions and event reconciliation | Jo / Rowan |
| Training | Requester and administrator sessions | Tessa / Marcus |
| Controls | Audit evidence and exception runbook | Simone / Grace |
| Evaluation | Results, defects, and go/no-go recommendation | Dana / Avery |

## Fees and credit treatment

The pilot fee is **$18,000**, payable under the pilot order. If EagleFord signs an enterprise agreement by September 30, 2026, the full paid pilot fee will be credited against the later implementation fee. It is not credited against subscription fees and does not create an additional discount on both categories.

An enterprise implementation price is not fixed by this pilot scope. For illustration, a later $72,000 implementation fee would leave $54,000 after the credit. That example is not an enterprise offer.

## Success evidence

The evaluation will report request-to-PO timing, handling effort, emergency share, user experience, and integration integrity. The primary operational aspiration is meaningful improvement from the 4.8-day baseline, with a working enterprise target of 2.5 days to be validated later.

Transaction duplication, unauthorized access, and untraceable approval history are red-line issues. They cannot be outweighed by a better average time.

## Responsibilities and exclusions

EagleFord supplies approved data, policy rules, user access, and an integration operator. Northstar supplies configuration and implementation support. Neither party will change financial authorities without Dana's approval.

The pilot is supervised. Daily reconciliation and reviewed audit exports may support evaluation, but they do not automatically satisfy production-readiness requirements.

## Exit and retention

At close, both teams will export results, classify defects, and decide whether to proceed, extend, or stop. No automatic enterprise conversion applies. Pilot access and data handling after evaluation follow the pilot terms and security-approved retention process.

## Related records

- [EF-020: Mutual action plan: evidence gates through a possible purchase](../02_solution_design/20_mutual-action-plan.md)
- [EF-022: Pilot test plan and evidence register](../03_validation/22_pilot-test-plan.md)
- [EF-025: Pilot kickoff transcript: what success does and does not mean](../03_validation/25_pilot-kickoff-transcript.md)
- [EF-029: Pilot results: measurable progress with two conditional acceptance cases](../03_validation/29_pilot-results-report.md)
- [EF-033: Commercial proposal: 240 named users and an explicit pilot credit](../04_commercial/33_pricing-proposal.md)
