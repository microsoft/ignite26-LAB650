---
document_id: EF-029
account: EagleFord
document_date: 2026-07-10
document_type: "Pilot evaluation report"
stage: "Pilot evaluation"
author: "Jo Ellis and Rowan Patel"
participants: "Jo Ellis; Rowan Patel; Dana Brooks; Owen Park; Caleb Turner; Simone Reed"
synthetic: true
---

# Pilot results: measurable progress with two conditional acceptance cases

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Cohort and results

The pilot ran June 1–July 10 at North Mesa and Red Creek with forty named users. At cutoff, **186 requests** had been submitted: **172 completed** and **14 open**. The fourteen open requests are excluded from completed-cohort cycle time and remain explicitly reported.

| Measure | Baseline | Pilot observation | Interpretation |
|---|---:|---:|---|
| Median request-to-PO | 4.8 calendar days | 2.9 calendar days | About 39.6% lower for completed cohort |
| Handling effort | 34 min/request | 21 min/request | Paired time study of 31 comparable observations |
| Emergency share | 7.5% | 11/186, about 5.9% | Directional only; small sample |
| Submitted / completed / open | Not the same cohort | 186 / 172 / 14 | Counts reconcile |
| UAT | 24 planned scenarios | 22 passed, 2 conditional | Not an unconditional production signoff |

The cycle-time comparison uses 172 comparable completed historical requests. It is observational, not randomized. Request mix, cleaned reference data, supervision, and supplier conditions may influence the result.

## User findings

Caleb reported that ownership and status visibility reduced follow-up calls. The effort study suggests thirteen minutes less handling per request, but it is too small to guarantee an enterprise-wide saving. Some users still needed a reminder that a saved text draft is not a submitted request.

## Integrity and defects

The June 18 retry incident caused fourteen minutes of degraded processing and seven requests needing reconciliation. No duplicate Dynamics PO was found in the reviewed requests. The callback deduplication defect was patched and retested; the original failed evidence remains in the register.

No unauthorized cross-location access was observed in the acceptance tests. This is a test finding, not a blanket claim that access risk is eliminated.

## Conditional acceptance

- **T13:** delegation expiry remains subject to a supervised control; production requires the approved expiry mechanism.
- **T22:** scheduled audit export and independent retention require completion before production.

Each condition has an owner and production gate. The 22 passed cases include the corrected integration replay test.

## Recommendation

Proceed to an operational sponsor review and a conservative financial assessment. Do not authorize enterprise deployment from this report alone. Priya, Simone, Owen, and Dana must accept their respective readiness areas.

## Claims not supported

The pilot does not establish cash payroll savings, invoice-automation benefits, a guaranteed 2.5-day enterprise cycle, or readiness at all twelve locations. The 5.0% emergency-share target is not yet achieved. Any annualized business case must show its assumptions separately from these observations.

## Related records

- [EF-007: Baseline measurement note: definitions before improvement claims](../01_discovery/07_baseline-measurement.md)
- [EF-022: Pilot test plan and evidence register](../03_validation/22_pilot-test-plan.md)
- [EF-027: Pilot incident report: duplicate callbacks without duplicate purchase orders](../03_validation/27_pilot-integration-incident.md)
- [EF-028: Corrective-action review: controlled replay and remaining pilot conditions](../03_validation/28_workaround-and-retest.md)
- [EF-030: Sponsor readout transcript: a recommendation is not funding](../03_validation/30_sponsor-readout-transcript.md)
- [EF-031: Business case: a thin first-year base case, not guaranteed cash savings](../04_commercial/31_business-case-model.md)
