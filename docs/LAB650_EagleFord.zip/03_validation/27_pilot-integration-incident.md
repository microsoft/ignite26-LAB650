---
document_id: EF-027
account: EagleFord
document_date: 2026-06-18
document_type: "Incident report and technical timeline"
stage: "Pilot execution"
author: "Owen Park, Enterprise Applications Manager"
participants: "Owen Park; Marcus Bell; Rowan Patel; Dana Brooks; Tessa Grant"
synthetic: true
---

# Pilot incident report: duplicate callbacks without duplicate purchase orders

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Incident summary

During a planned resilience exercise, a retry worker emitted duplicate status callbacks after a simulated response timeout. The pilot request queue experienced **14 minutes of degraded processing**. **Seven requests** required reconciliation. **No duplicate Dynamics purchase orders** were created in the reviewed set.

This was a bounded pilot incident, not an enterprise production outage. It is nevertheless relevant evidence against the proposed operating design.

## Timeline, UTC

| Time | Event |
|---|---|
| 14:02 | Team suppresses a callback after ERP acceptance for the planned test |
| 14:04 | Retry worker treats callback timeout as an unacknowledged transport event |
| 14:06 | Duplicate callbacks begin updating status in the pilot queue |
| 14:07 | Owen pauses the affected worker and blocks manual replay |
| 14:10 | Reconciliation confirms stable business keys in Dynamics |
| 14:16 | Normal processing restored; seven requests retained for review |

## Root cause and containment

The middleware retry path preserved the PO idempotency key but did not consistently preserve the callback-delivery correlation state. Dynamics correctly recognized repeated business keys, preventing duplicate purchase orders. The status consumer did not reliably suppress every repeated callback, creating confusing queue transitions.

The root cause is not “Dynamics was slow.” It is an incomplete end-to-end retry design. The architecture requirement existed, but its implementation and test coverage were insufficient.

Owen disabled automatic replay for ambiguous outcomes, assigned one operator to the queue, and reconciled all seven affected requests against ERP records. Users were told not to resubmit. The approved legacy route remained available for urgent requests with a reconciliation entry.

## Impact

Two requesters contacted procurement because a status appeared to move backward. One already approved request briefly displayed ERP processing again. No additional supplier order was authorized from that status change. The team found no missing approval events in the reviewed sample.

## Corrective actions

- Marcus: patch callback deduplication and preserve delivery correlation across restarts.
- Owen: add a restart-during-timeout test and supervise recovery.
- Rowan: update the demo evidence matrix to mark T18 failed pending retest.
- Jo: retain these requests in the pilot totals and disclose the incident in results.

## Resume criterion

The affected automation resumes only after Owen witnesses replay, restart, and duplicate-callback tests with expected outcomes. A clean retest does not erase the incident history.

**Communication decision:** Avery will include the issue in the sponsor readout. The account team will not describe “zero duplicate POs” as proof that no integrity defect occurred.

## Related records

- [EF-012: Solution architecture decision record: request workflow beside the ERP](../02_solution_design/12_solution-architecture.md)
- [EF-013: Integration mapping workshop: fields, states, and replay rules](../02_solution_design/13_integration-mapping.md)
- [EF-022: Pilot test plan and evidence register](../03_validation/22_pilot-test-plan.md)
- [EF-028: Corrective-action review: controlled replay and remaining pilot conditions](../03_validation/28_workaround-and-retest.md)
- [EF-029: Pilot results: measurable progress with two conditional acceptance cases](../03_validation/29_pilot-results-report.md)
