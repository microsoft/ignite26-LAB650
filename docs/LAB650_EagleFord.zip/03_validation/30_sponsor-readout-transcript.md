---
document_id: EF-030
account: EagleFord
document_date: 2026-07-16
document_type: "Executive readout transcript"
stage: "Business-case review"
author: "Avery Stone, Account Executive"
participants: "Luis Ortega; Dana Brooks; Priya Nair; Jo Ellis; Avery Stone; Rowan Patel"
synthetic: true
---

# Sponsor readout transcript: a recommendation is not funding

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Readout purpose

Luis reviewed the pilot findings and decided whether to recommend a commercial assessment. Maya was not present. The session did not approve spending or waive technical conditions.

## Transcript excerpts

**[00:04] Jo:** We received 186 requests, completed 172, and have fourteen open at cutoff. The completed-request median is 2.9 days versus 4.8 in the matched historical set. The caveat is that this was not a controlled experiment.

**[00:08] Luis:** Did the field do less work, or did your project team do work for them?

**[00:09] Rowan:** Both the product and the extra attention may contribute. Our time study found 21 minutes of handling compared with 34 before, but it covers only 31 comparable observations. We should use a conservative assumption in the financial case.

**[00:14] Priya:** The retry incident matters. The financial duplicate control worked, but callback handling did not. The fix passed retest. I still need the production runbook and ownership.

**[00:18] Luis:** I prefer that to a presentation saying there were no issues. What remains unresolved?

**[00:19] Rowan:** Delegation expiry and scheduled audit-export retention are conditional. The pilot can end with operating controls; production cannot start until the agreed gates are satisfied.

**[00:24] Dana:** I recommend moving forward to commercial review. Request visibility is materially better. I am not recommending that we deploy twelve locations at once.

**[00:28] Avery:** We will build a base case with capacity value separated from avoidable costs. Would you support taking that to Maya?

**[00:29] Luis:** Yes. But do not call released time cash savings. I am not reducing the team. If the first-year case is weak, say so.

**[00:34] Priya:** And do not bring me a signed contract with the security conditions relegated to an appendix nobody owns.

## Decisions

Luis supports a financial and commercial assessment. Dana remains the working champion. Priya accepts continued design work but withholds production approval. The preferred deployment approach is phased, beginning with the two pilot locations.

## Required next package

The business case must show base, downside, and upside assumptions; explain the pilot-fee credit; and identify implementation capacity. It must distinguish observed cycle improvement from modeled economic benefit.

Avery will coordinate the July 30 CFO review. Jo will validate the arithmetic. Grace and Owen will maintain the technical closure plan.

**Forecast implication:** an operational recommendation is positive evidence, but the deal remains subject to finance, procurement, legal, security, and delivery readiness.

## Related records

- [EF-029: Pilot results: measurable progress with two conditional acceptance cases](../03_validation/29_pilot-results-report.md)
- [EF-031: Business case: a thin first-year base case, not guaranteed cash savings](../04_commercial/31_business-case-model.md)
- [EF-032: CFO review transcript: capacity is not cash](../04_commercial/32_cfo-review-transcript.md)
- [EF-035: Security closure record: pilot conditions resolved with production controls](../04_commercial/35_security-closure-record.md)
