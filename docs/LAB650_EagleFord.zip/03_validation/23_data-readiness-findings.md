---
document_id: EF-023
account: EagleFord
document_date: 2026-05-13
document_type: "Data-quality assessment"
stage: "Pilot preparation"
author: "Jo Ellis, Procurement Operations Analyst"
participants: "Jo Ellis; Owen Park; Dana Brooks; Marcus Bell; Rowan Patel"
synthetic: true
---

# Data-readiness findings: retired cost centers and ambiguous locations

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Assessment scope

The team reviewed the reference lists intended for the two-location pilot: locations, assets, cost centers, and user-to-location assignments. This is a fictional readiness sample, not a complete audit of EagleFord master data.

The review exposed a risk that a cleaner interface could make bad reference data easier to distribute. The solution should not be judged solely by whether it accepts a file.

## Findings

| Finding | Sample observation | Consequence | Owner |
|---|---|---|---|
| Retired cost centers | 7 of 84 reference entries marked inactive | Requests may fail ERP validation | Owen |
| Alias collision | “NM” used informally for both North Mesa site and a maintenance group | Wrong-location interpretation | Dana |
| Unowned assets | 12 of 240 sample asset references lacked a current custodian | Routing ambiguity | Site administrators |
| User scope mismatch | 3 proposed users lacked confirmed location authorization | Access cannot be provisioned safely | Identity team |
| Free-text supplier names | Multiple spellings for one fictional supplier | Not a blocker; supplier master excluded | Procurement |

The denominators are specific to this readiness sample and must not be presented as company-wide defect rates.

## Workshop discussion

Owen proposed filtering inactive cost centers at import. Jo agreed but asked that rejected references remain in a reconciliation report. Silent omission would leave procurement unable to explain why an old value is missing.

Dana rejected a proposed automatic mapping from the ambiguous “NM” alias. The customer will choose explicit site codes, **NMESA** and **RCREEK**, for pilot request selection. Historical request text will not be rewritten.

Caleb's asset examples reinforced the decision to allow a free-text description when an exact asset reference is unavailable. That flexibility does not permit users to choose an unauthorized cost center.

## Remediation and readiness gate

EagleFord will approve the cleaned reference lists by May 18. Marcus will load only that approved version and record its hash in the readiness log. Rowan will rerun the bad-reference test after the load.

The three unconfirmed users remain unprovisioned until the identity owner resolves access. The team will not borrow another user's account to meet the forty-user target.

## Measurement implications

Improved master-data quality may contribute to pilot results. The final evaluation must disclose that the pilot includes both workflow changes and customer data cleanup; it cannot attribute all change to software alone.

**Decision:** proceed with remediation. No production data migration or broad master-data replacement is authorized by this exercise.

## Related records

- [EF-013: Integration mapping workshop: fields, states, and replay rules](../02_solution_design/13_integration-mapping.md)
- [EF-022: Pilot test plan and evidence register](../03_validation/22_pilot-test-plan.md)
- [EF-024: Pilot enablement plan: teach the exception, not just the form](../03_validation/24_pilot-enablement-plan.md)
- [EF-044: Migration rehearsal: carry open work, not every historical message](../05_delivery/44_migration-rehearsal.md)
