---
document_id: EF-026
account: EagleFord
document_date: 2026-06-12
document_type: "Pilot checkpoint notes"
stage: "Pilot execution"
author: "Jo Ellis, Procurement Operations Analyst"
participants: "Jo Ellis; Dana Brooks; Caleb Turner; Owen Park; Rowan Patel; Tessa Grant"
synthetic: true
---

# Pilot checkpoint: faster completed requests, incomplete evidence

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Snapshot

As of June 12, the pilot has **64 submitted requests**, of which **49 are completed** and **15 remain open**. This is an interim snapshot, not the final cohort. The preliminary completed-request median is 3.2 calendar days. Five requests are classified as emergency.

The group agreed not to compare the 3.2-day figure with the 4.8-day baseline as a final benefit claim. Short, completed requests dominate early results, while long-running requests may still be open.

## User feedback

Caleb reported fewer status calls for routine requests, but one user still interpreted “draft saved” as “sent.” The persistent warning was visible; the user's expectation was not corrected by the text alone. Tessa will add a practical scenario to the next shift briefing.

Red Creek participants liked knowing which approver had the next step. Procurement administrators asked for an exception owner to be visible without opening a detail panel. Rowan will assess the configuration rather than promise a custom feature.

## Control review

No unauthorized cross-location access or duplicate ERP purchase order has been observed in the pilot to date. That statement describes the evidence reviewed, not a guarantee of future behavior.

Delegation expiry and scheduled audit export remain open. The pilot uses approved substitute-approver records and reviewed exports. The team reiterated that these controls are temporary evaluation arrangements.

## Interpretation of progress

The largest apparent improvement is in clarification visibility. It is too early to claim that all improvement comes from automation. The cleaned reference data and daily attention from both teams may contribute.

Owen also noted that support responsiveness is unusually high because the implementation team is watching the pilot. Production readiness will require a support model that works without Rowan attending every check.

## Decisions and actions

| Action | Owner | Due |
|---|---|---|
| Repeat the draft-versus-submit scenario in shift briefing | Tessa / Caleb | June 16 |
| Expose exception ownership more clearly | Rowan | June 17 |
| Review integration retries under callback suppression | Owen / Marcus | June 18 |
| Keep open cohort beside median in weekly report | Jo | Next report |

## Commercial note

Avery asked whether the team wanted an enterprise quote immediately. Dana preferred to wait until the technical evidence was stronger. The seller accepted that sequence. Pricing pressure should not dictate the test plan.

**Next checkpoint:** review the resilience test and any resulting defects before discussing whether the pilot supports a broader recommendation.

## Related records

- [EF-025: Pilot kickoff transcript: what success does and does not mean](../03_validation/25_pilot-kickoff-transcript.md)
- [EF-027: Pilot incident report: duplicate callbacks without duplicate purchase orders](../03_validation/27_pilot-integration-incident.md)
- [EF-029: Pilot results: measurable progress with two conditional acceptance cases](../03_validation/29_pilot-results-report.md)
- [EF-030: Sponsor readout transcript: a recommendation is not funding](../03_validation/30_sponsor-readout-transcript.md)
