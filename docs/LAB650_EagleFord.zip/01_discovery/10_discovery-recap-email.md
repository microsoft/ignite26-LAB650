---
document_id: EF-010
account: EagleFord
document_date: 2026-03-10
document_type: "Customer recap email"
stage: "Solution qualification"
author: "Avery Stone, Account Executive"
participants: "Dana Brooks; Luis Ortega; Priya Nair; Avery Stone; Rowan Patel"
synthetic: true
---

# Discovery recap email: the buying problem and the next gate

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Customer-facing email

**From:** Avery Stone <avery.stone@northstar.example>  
**To:** Dana Brooks; Luis Ortega; Priya Nair  
**Subject:** EagleFord discovery recap and proposed evaluation sequence

Thank you for correcting our early process map. The problem we now understand is not simply “slow approvals.” It is an incomplete and poorly visible chain from field request to financial purchase order. Missing context causes rework, status calls interrupt operations, and urgent purchases can become difficult to reconcile.

The initial baseline is approximately 1,200 requests per month across twelve locations, a 4.8-calendar-day median request-to-PO time, 34 minutes of administrative effort per request, and a 7.5% emergency-request share. Jo owns these definitions. They are planning inputs, not audited financial benefits.

## What the evaluation should prove

1. A field user can submit a complete-enough request without finding a supplier part number first.
2. The requester can distinguish submission, approval, ERP processing, and PO issuance.
3. EagleFord can preserve its existing authorities, financial master data, and safety processes.
4. IT can operate the integration and recover failed transactions without vendor-only intervention.
5. Improvement can be measured without counting open or failed requests as zero-duration successes.

## What we are not proposing

We are not replacing Dynamics, automating invoice payments, guaranteeing supplier stock, or offering full offline submission. FieldBridge will not authorize safety activity. These exclusions should remain visible through the pilot and commercial review.

## Proposed sequence

| Step | Working date | Required output |
|---|---|---|
| Scenario presentation | March 17 | Customer correction of proposed workflow |
| Architecture workshop | March 20 | Agreed integration boundaries |
| Security intake | March 27 | Risks and required evidence identified |
| Demonstration | April 2 | Evidence against must-have requirements |
| Evaluation plan | April 21 | Customer-owned decision gates and owners |

These are working dates, not a request for purchase authorization. We will revise the plan if your team cannot provide the necessary owners.

## Reply from Dana, March 10

“This captures the problem. Please keep AP impact as a hypothesis. Nadia has not agreed that cleaner requests will reduce invoice effort. Also, the North Mesa field team will not accept language suggesting that a saved draft is a submitted request.”

## Account-team note

The recap is accepted with those corrections. Discovery is sufficiently developed to proceed to solution validation. Funding, final license quantities, pilot authorization, and an enterprise deployment remain unapproved.

**Avery's next action:** circulate the scenario presentation in advance and ask Priya whether the architecture workshop requires a separate integration-services representative.

## Related records

- [EF-007: Baseline measurement note: definitions before improvement claims](../01_discovery/07_baseline-measurement.md)
- [EF-011: Presentation summary: one request, four distinct states](../02_solution_design/11_scenario-presentation-summary.md)
- [EF-012: Solution architecture decision record: request workflow beside the ERP](../02_solution_design/12_solution-architecture.md)
- [EF-020: Mutual action plan: evidence gates through a possible purchase](../02_solution_design/20_mutual-action-plan.md)
