---
document_id: EF-006
account: EagleFord
document_date: 2026-02-20
document_type: "Field observation notes"
stage: "Discovery"
author: "Rowan Patel, Solutions Engineer"
participants: "Caleb Turner; Jo Ellis; Rowan Patel"
synthetic: true
---

# North Mesa field observation: the five-minute request

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Observation conditions

The session simulated a supervisor requesting a replacement coupling from a mobile browser. Caleb walked Rowan and Jo through a typical sequence from the yard to the office. No production system was changed and no supplier order was placed. Observations are descriptive, not a formal usability study.

## Sequence observed

1. Caleb photographed the equipment nameplate and the worn coupling.
2. He entered a short description in a message to procurement.
3. The asset identifier was legible in one image but not the other.
4. A cost-center question arrived after he had returned to another task.
5. He called the office to check whether the request had been received.

The physical work was straightforward. The interruption came from reconstructing context after the first handoff. Caleb said a “complete” form would be acceptable if it asked for information he could realistically provide at the equipment.

## Voice of the user

> “I can tell you which unit is down and what it needs to do. I cannot always tell you the exact supplier part number. If that field is mandatory, I will type something just to get through it.”

> “A spinning wheel is worse than a clear failure. If it says sent, I need to know somebody has it.”

> “I do not want a green checkmark that means approved when purchasing still has to do another step.”

These comments change the proposed design. Part number should be optional for free-text maintenance requests. Submission acknowledgment must be separate from approval, and approval must be separate from PO creation.

## Environmental constraints

Mobile connectivity varied between the office and the yard. The working proposal is online submission with a locally recoverable text draft, not guaranteed offline operation. Attachment retry and unsent-state messaging require explicit testing. Users must not be encouraged to store sensitive photographs on shared devices.

Caleb also uses gloves. The next demonstration should use large touch targets and avoid a dense grid as the first screen. This is a design preference to validate, not a claim that the product is certified for industrial glove use.

## Acceptance ideas

- A first-time user can submit a routine request in under five minutes after brief training.
- A network failure cannot display “submitted” until the server confirms receipt.
- The requester can see who owns the next step without calling procurement.
- Emergency requests expose the approved escalation route rather than silently bypassing policy.

## Actions

Rowan will reproduce the weak-signal scenario in a controlled test. Jo will select both simple and complex requests for the baseline. Caleb will nominate one backup field evaluator so the pilot does not depend on his availability.

**Boundary:** this exercise does not establish a safe operating procedure for devices in hazardous areas. EagleFord retains responsibility for site device-use rules.

## Related records

- [EF-003: Discovery call transcript: where a request disappears](../01_discovery/03_discovery-call-transcript.md)
- [EF-015: Demonstration transcript: show the broken path](../02_solution_design/15_demonstration-transcript.md)
- [EF-017: Nonfunctional requirements and production-readiness gates](../02_solution_design/17_nonfunctional-requirements.md)
- [EF-024: Pilot enablement plan: teach the exception, not just the form](../03_validation/24_pilot-enablement-plan.md)
