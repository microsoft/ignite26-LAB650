---
document_id: EF-008
account: EagleFord
document_date: 2026-03-03
document_type: "Workshop record"
stage: "Discovery"
author: "Dana Brooks, Director of Procurement"
participants: "Dana Brooks; Priya Nair; Owen Park; Caleb Turner; Miguel Santos; Rowan Patel; Avery Stone"
synthetic: true
---

# Requirements workshop: must-haves, exclusions, and ownership

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Workshop objective

The group converted discovery findings into a shortlist of requirements suitable for evaluating FieldBridge and other options. Priya asked that the list distinguish a genuine pilot gate from a preference. Caleb requested that “easy to use” be replaced by observable actions.

## Prioritized requirements

| ID | Requirement | Priority | Customer owner |
|---|---|---|---|
| R-01 | Mobile-browser request creation with clear submitted/unsent state | Must | Caleb |
| R-02 | Entra ID SSO and controlled user provisioning | Must | Priya |
| R-03 | Approval routing by location, cost center, and request value | Must | Dana |
| R-04 | Dynamics PO handoff with duplicate-prevention controls | Must | Owen |
| R-05 | Searchable event history and audit export | Must | Simone, review pending |
| R-06 | Explicit emergency escalation without safety authorization | Must | Miguel |
| R-07 | Report request time, integration failures, and exception volume | Must | Jo |
| R-08 | Recoverable text drafts under weak connectivity | Should | Caleb |
| R-09 | Configurable delegation with expiry | Should | Dana |
| R-10 | Supplier catalog and invoice automation | Out of initial scope | Nadia |

## Important discussion

**Priya:** “If the design makes FieldBridge the authoritative source for cost centers, we are creating another master-data problem.”

**Owen:** “Read-only reference data can come from our existing services. PO creation must use our integration layer. Direct database writes are not acceptable.”

**Miguel:** “An emergency checkbox cannot become permission to purchase unsafe equipment or skip a permit. The product should point people to the existing policy.”

**Caleb:** “I can tolerate a short request. I will not tolerate not knowing whether it went through.”

## Design consequences

Dynamics remains the system of record for purchase orders and financial coding. EagleFord's integration layer mediates transactions. FieldBridge owns the request workflow and its event history, not supplier master data.

Approval limits must be tested with EagleFord-approved sample thresholds. The sales team must not embed guessed dollar authorities into a production configuration. All pilot rules will be reviewed by Dana before activation.

## Unresolved issues

- Simone has not yet accepted the proposed audit retention and export model.
- The actual requester-versus-approver license mix is unknown.
- Offline submission is not a must-have if online acknowledgment and draft recovery are reliable.
- Delegation needs segregation-of-duties rules, especially when an approver is also the requester.

## Decisions

The team approved these requirements for an RFI, not as evidence that FieldBridge satisfies them. Avery will coordinate responses. Rowan will show each requirement's status as standard capability, configuration, integration dependency, or gap.

**Next checkpoint:** March 10 discovery recap. Requirements may change through a dated decision record; they should not silently shift during scoring.

## Related records

- [EF-009: FieldBridge RFI response and explicit capability gaps](../01_discovery/09_rfi-response.md)
- [EF-012: Solution architecture decision record: request workflow beside the ERP](../02_solution_design/12_solution-architecture.md)
- [EF-017: Nonfunctional requirements and production-readiness gates](../02_solution_design/17_nonfunctional-requirements.md)
- [EF-022: Pilot test plan and evidence register](../03_validation/22_pilot-test-plan.md)
