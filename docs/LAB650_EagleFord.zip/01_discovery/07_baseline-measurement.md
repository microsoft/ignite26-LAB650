---
document_id: EF-007
account: EagleFord
document_date: 2026-02-24
document_type: "Measurement report"
stage: "Discovery"
author: "Jo Ellis, Procurement Operations Analyst"
participants: "Jo Ellis; Dana Brooks; Nadia Hassan; Rowan Patel"
synthetic: true
---

# Baseline measurement note: definitions before improvement claims

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Purpose and source

This note establishes the baseline for evaluating procurement intake. Jo assembled a fictional, anonymized process extract for January–February 2026. Volumes are rounded planning estimates; timing metrics use a cleaned sample. The note is not a financial audit and does not establish causation.

## Baseline metrics

| Metric | Baseline | Definition |
|---|---:|---|
| Average monthly intake | 1,200 requests | Across all twelve locations |
| Annualized planning volume | 14,400 requests | Monthly estimate multiplied by twelve |
| Median request-to-PO time | 4.8 calendar days | Submission timestamp to Dynamics PO issuance |
| Handling effort | 34 minutes per request | Procurement and requester administrative effort combined |
| Emergency-request share | 7.5% | Requests accepted under EagleFord's exception policy |
| Potential pilot comparison set | 172 completed requests | Comparable request types at proposed pilot locations |

The 34-minute estimate comes from staff time diaries and process reconstruction. It is less precise than timestamp data and must be retested during the pilot. Calendar-day elapsed time includes weekends; handling minutes do not.

## Cleaning and exclusions

Withdrawn requests, test records, and requests without a reliable starting timestamp were excluded from cycle-time calculations. Requests still open at the extract cutoff are reported separately rather than assigned zero duration.

Supplier quotation waiting time remains inside end-to-end elapsed time. This is intentional because the customer experiences the full wait, but it means FieldBridge cannot claim responsibility for all observed change. Request complexity and supplier availability could influence the result.

## Measurement plan

For the pilot, retain the submission identifier, location, request type, emergency flag, approval events, ERP acknowledgment, and PO-issued timestamp. Use UTC for event storage and local display for users. Count a purchase order as issued only when Dynamics returns the PO identifier.

The primary cycle comparison will use completed pilot requests and the 172-request historical comparison set. Report the open pilot cohort separately to make survivorship bias visible. The evaluation is not randomized and should not be presented as a controlled experiment.

## Financial interpretation

Time released is **capacity**, not automatically payroll savings. No headcount reduction is planned. The eventual business case should separate capacity value, avoidable external costs, and estimated leakage reduction.

Emergency volume at baseline is approximately 1,080 requests annually: 14,400 × 7.5%. A reduction to 5.0% would mean 360 fewer emergency requests, but neither that target nor its dollar impact is approved yet.

## Ownership

Jo owns metric definitions and reconciliation. Dana approves exception classifications. Owen must validate ERP event semantics once IT joins. Rowan may calculate pilot results but cannot change the denominator without Jo's written agreement.

## Related records

- [EF-005: Procurement and AP interview: rework before and after the PO](../01_discovery/05_procurement-interview.md)
- [EF-021: Pilot statement of work: two locations, bounded evidence](../03_validation/21_pilot-statement-of-work.md)
- [EF-022: Pilot test plan and evidence register](../03_validation/22_pilot-test-plan.md)
- [EF-029: Pilot results: measurable progress with two conditional acceptance cases](../03_validation/29_pilot-results-report.md)
- [EF-031: Business case: a thin first-year base case, not guaranteed cash savings](../04_commercial/31_business-case-model.md)
