---
document_id: EF-005
account: EagleFord
document_date: 2026-02-17
document_type: "Interview transcript and findings"
stage: "Discovery"
author: "Rowan Patel, Solutions Engineer"
participants: "Dana Brooks; Nadia Hassan; Jo Ellis; Rowan Patel; Avery Stone"
synthetic: true
---

# Procurement and AP interview: rework before and after the PO

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Interview context

Dana brought three redacted examples: a pump seal replacement, a planned inspection service, and an urgent rental compressor. Nadia joined to explain why an apparently completed purchase can still generate downstream work. The group agreed to discuss process patterns, not supplier pricing or identifiable employee performance.

## Dialogue excerpts

**Dana:** The rental compressor had approval in a text message. That did not mean the supplier had a PO number. Procurement had to reconstruct who authorized it and which location should carry the expense.

**Nadia:** When the invoice arrives, our team does not see the original conversation. We see a supplier, an amount, and sometimes a reference that is not a PO. We ask procurement, procurement asks the supervisor, and the original urgency has become an accounting cleanup.

**Rowan:** Would storing the conversation in FieldBridge solve that?

**Nadia:** Only if the approved information reaches Dynamics. A second place to search would help less than you think. I do not want AP opening another system for every invoice.

**Jo:** Some requests are complete on the first attempt. We should capture that too. If you only study our worst examples, the business case will be inflated.

**Avery:** Which events should count as start and finish?

**Dana:** Start when the user submits a request that enters our queue. Finish when Dynamics issues a PO number. We can separately track how much time was waiting for missing information.

## Process findings

| Handoff | Common failure | Required treatment |
|---|---|---|
| Requester to procurement | Missing asset, location, or cost center | Validate required fields without requiring a perfect catalog |
| Procurement to approver | Approver unclear or unavailable | Resolve ownership and delegation explicitly |
| Approved request to ERP | Request appears approved but has no PO | Display the integration state separately |
| Supplier invoice to AP | Missing or inaccurate PO reference | Keep Dynamics as financial system of record |

## Scope decisions

The initial solution will not ingest invoices or automate payments. It may improve upstream information quality, but AP savings cannot be claimed without evidence. Nadia will advise on required PO fields and review exception reporting.

“Emergency” must mean a customer-defined operational exception, not simply a requester choosing the fastest route. Miguel's HSE process remains separate. Emergency intake may capture an authorization reference, but the platform will not issue safety permits.

## Measurement and follow-up

Jo will assemble an anonymized January–February baseline across all locations. Rowan will distinguish request status from ERP status in the solution storyboard. Avery will avoid describing invoice cleanup as an included product feature.

**Open question:** how much of the observed elapsed time is internal processing versus supplier quotation time? The first baseline will report elapsed time and caveats rather than attribute all delay to procurement.

## Related records

- [EF-007: Baseline measurement note: definitions before improvement claims](../01_discovery/07_baseline-measurement.md)
- [EF-008: Requirements workshop: must-haves, exclusions, and ownership](../01_discovery/08_requirements-workshop.md)
- [EF-013: Integration mapping workshop: fields, states, and replay rules](../02_solution_design/13_integration-mapping.md)
- [EF-031: Business case: a thin first-year base case, not guaranteed cash savings](../04_commercial/31_business-case-model.md)
