---
document_id: EF-004
account: EagleFord
document_date: 2026-02-12
document_type: "Internal sales planning note"
stage: "Discovery"
author: "Avery Stone, Account Executive"
participants: "Avery Stone; Rowan Patel; Quinn Foster"
synthetic: true
---

# Stakeholder map and buying-process hypotheses

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Confirmed relationships

| Stakeholder | Role | What they care about | Current position |
|---|---|---|---|
| Luis Ortega | VP Operations | Request visibility without slowing field work | Discovery sponsor; not yet funding sponsor |
| Dana Brooks | Director of Procurement | Complete requests, fewer status calls, controlled exceptions | Working champion candidate |
| Caleb Turner | North Mesa field supervisor | Fast intake, reliable weak-signal behavior | Influential evaluator; skeptical of added administration |
| Maya Chen | CFO | Budget discipline and credible benefits | Not engaged directly |
| Priya Nair | CIO | System boundaries and supportability | Introduction requested |
| Owen Park | Enterprise Applications Manager | Integration ownership and failure recovery | Expected technical lead |
| Simone Reed | Security Lead | Identity, auditability, data handling | Approval process not yet known |
| Nadia Hassan | AP Manager | Invoice matching and purchase-order quality | Interview requested |
| Erin Walsh | Commercial Counsel | Liability, termination, data processing | No active review yet |
| Miguel Santos | HSE Director | Separation from safety authorization | Boundary stakeholder |
| Tessa Grant | Transformation PM | Delivery sequencing and accountable owners | Potential rollout lead |
| Jo Ellis | Procurement Operations Analyst | Reporting definitions and practical administration | Likely measurement owner |

## Influence is not the same as authority

Dana is actively coordinating access, but calling her a confirmed champion would be premature. A champion should help us understand the decision process, test our assumptions internally, and tell us when our proposal is not viable. Agreeing to a meeting is insufficient.

Luis explicitly sponsored assessment, not acquisition. Maya's financial approval threshold is still unknown. Priya may be able to veto an architecture without owning the purchase budget. Caleb has no commercial authority but could determine whether the field adopts the workflow.

## Hypothesized buying path

Discovery → requirements agreement → technical and security review → bounded pilot → operational evidence → CFO business-case review → procurement and legal negotiation → signature.

This sequence is provisional. Procurement may require a competitive evaluation before a pilot, and security may require a review before any realistic data is loaded. Avery must ask rather than assume.

## Relationship risks

1. **Single-threading through Dana.** Mitigation: request introductions with her consent and keep her copied on material updates.
2. **Selling around IT.** Mitigation: include Owen before discussing integration effort or dates.
3. **Treating field objections as resistance.** Mitigation: give Caleb ownership of practical acceptance scenarios.
4. **Creating executive surprise.** Mitigation: ask Luis which evidence Maya needs before building a financial case.

## Next two-week coverage plan

Avery owns the buying-process questions. Rowan owns technical discovery. Neither should independently promise functionality or discount terms. Quinn will join an executive meeting only after Dana and Luis agree it is useful.

**Evidence still missing:** budget owner confirmation, procurement policy, formal selection criteria, a dated customer decision plan, and a competitor shortlist. The CRM should retain these as unknown, not fill them with optimistic assumptions.

## Related records

- [EF-003: Discovery call transcript: where a request disappears](../01_discovery/03_discovery-call-transcript.md)
- [EF-008: Requirements workshop: must-haves, exclusions, and ownership](../01_discovery/08_requirements-workshop.md)
- [EF-020: Mutual action plan: evidence gates through a possible purchase](../02_solution_design/20_mutual-action-plan.md)
- [EF-032: CFO review transcript: capacity is not cash](../04_commercial/32_cfo-review-transcript.md)
