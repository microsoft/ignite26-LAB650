---
document_id: EF-009
account: EagleFord
document_date: 2026-03-06
document_type: "Requirements response"
stage: "Solution qualification"
author: "Rowan Patel, Solutions Engineer"
participants: "Rowan Patel; Dana Brooks; Owen Park; Simone Reed"
synthetic: true
---

# FieldBridge RFI response and explicit capability gaps

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Response conventions

This response is specific to EagleFord's initial scope. “Supported” is not a promise that configuration and integration are already complete. Items marked conditional require a customer decision or test. No roadmap feature is included in the proposed price or acceptance basis.

## Requirement response

| Requirement | Response | Evidence or dependency |
|---|---|---|
| R-01 Mobile intake | Supported online | Demonstrate server acknowledgment and failed-upload behavior |
| R-02 Entra ID identity | Supported with configuration | Customer tenant policies and group mapping required |
| R-03 Approval routing | Supported with configuration | Customer-approved authority matrix required |
| R-04 Dynamics handoff | Integration work required | Use EagleFord middleware and an idempotency key |
| R-05 Audit history/export | Conditional | Security review must accept retention, export schema, and access controls |
| R-06 Emergency route | Supported with configuration | References policy; does not provide safety clearance |
| R-07 Operational reporting | Supported for workflow events | ERP timestamps require integration reconciliation |
| R-08 Draft recovery | Limited | Text draft recovery; no guaranteed offline submission or attachment persistence |
| R-09 Delegation | Conditional | Expiry and conflict rules must be verified |
| R-10 Invoice automation | Excluded | Not part of the evaluation or commercial scope |

## Integration boundary

FieldBridge sends an approved purchase request to EagleFord's Azure integration layer. That layer validates financial references, invokes the approved Dynamics interface, and returns a PO identifier or a failure reason. A successful approval does not imply a purchase order exists.

Reference data flows from EagleFord to FieldBridge on a controlled schedule. The design must tolerate a retired cost center without guessing a replacement. Invalid references go to a named exception owner.

## Security and operations

Northstar proposes a US-hosted production tenant, role-scoped access, Entra ID SSO, and audit exports. Specific contractual commitments on incident notification, availability, recovery, retention, and deletion remain subject to the security and legal process. Marketing language is not a substitute for the signed agreement.

Production data should not be loaded before the security gate. Demonstrations will use invented suppliers, assets, and requests. Employee health data, bank details, government identifiers, and detailed safety-incident narratives are not required.

## Gaps and non-goals

FieldBridge does not replace a CMMS, determine whether equipment is safe to operate, verify supplier inventory, or autonomously approve spending. Full offline operation is unavailable in the proposed solution. If that becomes mandatory, EagleFord should treat it as a fit issue rather than rely on an uncommitted enhancement.

## Requested customer response

Dana should confirm that the exclusions are acceptable. Owen should nominate an integration owner. Simone should provide the formal security questionnaire. The next demonstration will use the pump-seal scenario from discovery, including an intentional failure path rather than only a happy path.

## Related records

- [EF-008: Requirements workshop: must-haves, exclusions, and ownership](../01_discovery/08_requirements-workshop.md)
- [EF-011: Presentation summary: one request, four distinct states](../02_solution_design/11_scenario-presentation-summary.md)
- [EF-014: Security intake: evidence requested and statements not yet accepted](../02_solution_design/14_security-questionnaire.md)
- [EF-015: Demonstration transcript: show the broken path](../02_solution_design/15_demonstration-transcript.md)
