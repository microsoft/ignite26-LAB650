---
document_id: EF-001
account: EagleFord
document_date: 2026-02-03
document_type: "Internal account brief"
stage: "Prospecting"
author: "Avery Stone, Account Executive"
participants: "Avery Stone; Rowan Patel; Quinn Foster"
synthetic: true
---

# EagleFord account brief and initial sales hypothesis

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Account context

EagleFord Energy is a fictional, privately held energy operator with twelve operating locations and a central services office in Denver. Its procurement team supports field maintenance, planned shutdowns, and small capital projects. Management describes the company as operationally disciplined but inconsistent in the handoff between a field request and an approved purchase order.

Northstar Systems is pursuing an opportunity for **FieldBridge**, its procurement intake and approval platform. FieldBridge is not an ERP, a warehouse management system, or a safety-permit application. The opening hypothesis is that a common request workflow can improve visibility without replacing EagleFord's system of financial record.

## What we know versus what we assume

| Topic | Current evidence | Confidence and next step |
|---|---|---|
| Fragmented intake | Dana Brooks mentioned email, spreadsheets, and text messages during a trade-event conversation | Customer-reported; validate with actual examples |
| ERP | Customer says Microsoft Dynamics 365 Finance is in use | Confirm integration ownership and permitted interfaces |
| Scale | Twelve operating locations | Confirm active users and transaction volumes |
| Urgency | A planned summer maintenance window | Determine whether this creates a buying deadline |
| Budget | No approved budget disclosed | Do not imply funding exists |

No quantified savings, formal champion, or committed decision date exists yet. The initial CRM stage remains Prospecting. Do not copy vendor benchmark numbers into customer-facing materials as if they were EagleFord results.

## Relationship strategy

Dana Brooks, Director of Procurement, is the likely working sponsor. Luis Ortega, VP Operations, may own the operational problem. Maya Chen, CFO, is a potential economic buyer, but we have not met her. Priya Nair, CIO, will likely control architecture approval. These are hypotheses, not confirmed buying roles.

The first meeting should establish where requests enter, who checks cost codes, what causes rework, and how urgent purchases bypass normal controls. Ask for one routine and one emergency request to be walked through end to end.

## Initial opportunity boundaries

The proposed entry point is two locations, not an enterprise deployment. Avoid leading with autonomous purchasing or promising that approval routing resolves supplier availability. A product tour before discovery would encourage feature comparisons without an agreed problem definition.

## Account-team actions

- Avery: request a 45-minute discovery session with Dana and an operations representative by February 10.
- Rowan: prepare a blank process map and questions about ERP boundaries; no architecture commitment yet.
- Quinn: reserve executive support but do not contact Luis independently.

**Exit criterion for discovery:** a customer-confirmed problem statement, an accountable sponsor, and agreement on a measurable evaluation. A friendly introduction alone does not qualify the deal.

## Related records

- [EF-002: Introductory email thread: getting the right people into discovery](../01_discovery/02_introductory-email-thread.md)
- [EF-003: Discovery call transcript: where a request disappears](../01_discovery/03_discovery-call-transcript.md)
- [EF-004: Stakeholder map and buying-process hypotheses](../01_discovery/04_stakeholder-map.md)
