---
document_id: EF-040
account: EagleFord
document_date: 2026-09-25
document_type: "Contract and order summary"
stage: "Closed Won"
author: "Avery Stone, Account Executive"
participants: "Maya Chen; Erin Walsh; Quinn Foster; Noah Evans; Avery Stone"
synthetic: true
---

# Executed agreement summary and order reconciliation

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Execution record

The fictional enterprise agreement and order were executed on **September 25, 2026** by authorized representatives for EagleFord and Northstar. This document is a readable summary of the simulated transaction, not a real contract or legal instrument.

**Term:** October 1, 2026–September 30, 2029.  
**Entitlement:** 240 named users across twelve locations.  
**Initial deployment:** phased, beginning with North Mesa and Red Creek.

## Financial reconciliation

| Item | Economic amount |
|---|---:|
| Annual subscription | $180,000 |
| Three-year subscription | $540,000 |
| Implementation, including pilot | $72,000 |
| Total three-year commitment | **$612,000** |
| Pilot previously paid and credited | ($18,000) |
| Remaining commitment | **$594,000** |

The first-year economic cost is $252,000, including the pilot. The first-year amount remaining after the paid pilot is $234,000 before tax. The $54,000 remaining implementation fee is invoiced in two $27,000 milestones: configuration acceptance and first-wave go-live. Subscription is invoiced annually in advance.

Annual list subscription was $216,000; the agreed $180,000 is a $36,000 reduction, about 16.7%. Subscription pricing is fixed during the initial term. The first like-for-like renewal increase is capped at 3%; new scope is separately ordered.

## Scope and service terms

Included: intake, approval workflows, agreed reporting, defined Dynamics integration, and the scoped enablement. Excluded: invoice automation, supplier onboarding, warehouse inventory, and full offline submission. Additional users require a written order; there is no automatic excess-user billing.

The hosted-service commitment is 99.9% monthly availability with defined exclusions and service credits. RTO is eight hours and RPO four hours under the agreed definitions. Customer middleware and Dynamics have separate ownership.

Confirmed incidents affecting customer data require notice without undue delay and no later than twenty-four hours after confirmation. The agreement defines the trigger and process. The negotiated confidentiality/data-protection super-cap is twice annual subscription fees, subject to the final legal definitions and exceptions.

## Readiness and handoff

Security-control design is accepted; production activation still requires deployment evidence. Thirteen months of searchable application events and seven-year independent customer retention remain distinct obligations.

No guaranteed financial outcome or twelve-location launch date was promised. Capacity value is not contracted cash savings. Avery may now record Closed Won, but Marcus and Lena must receive the full limitations and owner list before execution work proceeds.

## Related records

- [EF-033: Commercial proposal: 240 named users and an explicit pilot credit](../04_commercial/33_pricing-proposal.md)
- [EF-035: Security closure record: pilot conditions resolved with production controls](../04_commercial/35_security-closure-record.md)
- [EF-038: Internal concession approval and forecast review](../04_commercial/38_concession-approval-memo.md)
- [EF-039: Executive decision meeting: proceed for control, with accountable economics](../04_commercial/39_executive-decision-meeting.md)
- [EF-041: Sales-to-success handoff: promises, limitations, and the customer narrative](../05_delivery/41_sales-to-success-handoff.md)
