---
document_id: EF-038
account: EagleFord
document_date: 2026-09-10
document_type: "Internal deal approval memo"
stage: "Final negotiation"
author: "Quinn Foster, Regional VP Sales"
participants: "Quinn Foster; Avery Stone; Noah Evans; Marcus Bell; Lena Ortiz"
synthetic: true
---

# Internal concession approval and forecast review

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Approval request

Avery requests authority to close the EagleFord agreement at $180,000 annual subscription for three years, preserving 240 named users and the defined twelve-location entitlement. The customer requested $165,000, but the proposed final package holds the annual amount and addresses scope certainty and renewal protection instead.

## Approved package

| Item | Approved position | Boundary |
|---|---|---|
| Annual subscription | $180,000 | Fixed during initial three-year term |
| Implementation | $72,000 total | $18,000 pilot credit; $54,000 balance |
| Implementation balance billing | Two $27,000 milestones | Configuration acceptance and first-wave go-live |
| Renewal increase | Maximum 3% for like-for-like scope at first renewal | New scope separately ordered |
| Extra users | Written order required | No automatic overage invoice |
| Enablement | Retain agreed training | No unpriced unlimited sessions |
| Availability | 99.9% monthly | Negotiated exclusions and service credits |

The package is approved for negotiation, not a statement that EagleFord has accepted it. Do not describe the 3% renewal cap as an annual increase during the initial fixed-price term.

## Legal direction

Counsel has authority to finalize a confidentiality-and-data-protection super-cap of two times annual subscription fees, subject to the detailed exceptions and definitions in the agreement. General liability and special exclusions remain governed by the final text. This memo is not a substitute for counsel's legal interpretation.

Grace's security closure record is accepted as evidence for the defined scope. Deployment checklist completion remains required. Commercial urgency must not override that gate.

## Revenue and commitment reconciliation

Annual recurring subscription: $180,000. Three-year subscription: $540,000. One-time implementation including the paid pilot: $72,000. Total economic commitment: $612,000. Remaining commitment after the $18,000 pilot: $594,000.

Do not record $612,000 as annual recurring revenue. Do not treat the pilot credit as another $18,000 discount on top of the $72,000 implementation total.

## Forecast assessment

Operational sponsorship is confirmed. Security-control review is complete for the defined design. Maya's financial approval, final legal language, authorized signature, and customer resource commitment remain open.

The opportunity remains a late-stage forecast, not Closed Won. Avery should move it only when the agreement is executed and the required order evidence is present.

## Handoff condition

Marcus and Lena require a documented list of exclusions, known limitations, success metrics, and named customer owners before delivery begins. A clean signature without a clean handoff is not an acceptable account outcome.

## Related records

- [EF-031: Business case: a thin first-year base case, not guaranteed cash savings](../04_commercial/31_business-case-model.md)
- [EF-035: Security closure record: pilot conditions resolved with production controls](../04_commercial/35_security-closure-record.md)
- [EF-037: Commercial negotiation transcript: discount, scope, and implementation risk](../04_commercial/37_commercial-negotiation-transcript.md)
- [EF-039: Executive decision meeting: proceed for control, with accountable economics](../04_commercial/39_executive-decision-meeting.md)
- [EF-040: Executed agreement summary and order reconciliation](../04_commercial/40_executed-agreement-summary.md)
- [EF-041: Sales-to-success handoff: promises, limitations, and the customer narrative](../05_delivery/41_sales-to-success-handoff.md)
