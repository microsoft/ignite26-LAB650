---
document_id: EF-031
account: EagleFord
document_date: 2026-07-23
document_type: "Business-case analysis"
stage: "Business-case review"
author: "Jo Ellis and Avery Stone"
participants: "Jo Ellis; Avery Stone; Dana Brooks; Luis Ortega"
synthetic: true
---

# Business case: a thin first-year base case, not guaranteed cash savings

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Basis and limitations

The model uses 14,400 annual requests. It separates staff capacity from avoidable external costs and estimated leakage reduction. No reduction in headcount is assumed. The proposed $180,000 annual subscription and $72,000 implementation fee are working commercial assumptions, not an accepted quote.

## Base annual value

| Component | Calculation | Modeled annual value |
|---|---|---:|
| Capacity released | 14,400 × 12 min ÷ 60 × $48/hour × 70% realization | $96,768 |
| Avoidable expedite cost | 14,400 × (7.5% − 5.0%) × $185 | $66,600 |
| Purchase leakage reduction | Customer planning estimate, capped pending validation | $90,000 |
| Total | Sum of above | **$253,368** |

Twelve minutes is below the thirteen-minute pilot observation. The $48 rate is a blended loaded-cost assumption, not an employee salary. Seventy-percent realization reflects partial adoption and time that cannot be redeployed.

The emergency target is not a pilot result: eleven of 186 pilot requests were emergency, approximately 5.9%. The $185 avoidable cost per emergency and $90,000 leakage estimate require ongoing customer evidence. Neither is guaranteed.

## Costs and payback

Annual subscription: $180,000. One-time implementation: $72,000. First-year economic cost: **$252,000**. Base recurring net value: **$73,368**. Base first-year net value: **$1,368**, about **0.54%** of first-year cost.

Simple implementation payback at steady-state net value is $72,000 ÷ $73,368 × 12 = **11.8 months**. This excludes adoption ramp, discounting, tax, and customer internal implementation costs; it is not a cash-flow forecast.

The $18,000 paid pilot is credited within the $72,000 implementation total. Do not add it again to first-year cost or subtract it twice.

## Sensitivity

| Case | Capacity assumption | Expedite value | Leakage value | Total annual value |
|---|---|---:|---:|---:|
| Downside | 6 min, 50% realization = $34,560 | $39,960 | $30,000 | $104,520 |
| Base | 12 min, 70% = $96,768 | $66,600 | $90,000 | $253,368 |
| Upside | 18 min, 70% = $145,152 | $66,600 | $90,000 | $301,752 |

The downside does not cover the recurring subscription. The upside uses an eighteen-minute saving not established by the pilot.

## Recommendation

Present the uncertainty directly to Maya. The purchase may still be justified by control and visibility, but those benefits should not be converted into invented dollar savings. Confirm internal delivery costs before a final financial decision.

## Related records

- [EF-007: Baseline measurement note: definitions before improvement claims](../01_discovery/07_baseline-measurement.md)
- [EF-029: Pilot results: measurable progress with two conditional acceptance cases](../03_validation/29_pilot-results-report.md)
- [EF-032: CFO review transcript: capacity is not cash](../04_commercial/32_cfo-review-transcript.md)
- [EF-033: Commercial proposal: 240 named users and an explicit pilot credit](../04_commercial/33_pricing-proposal.md)
- [EF-039: Executive decision meeting: proceed for control, with accountable economics](../04_commercial/39_executive-decision-meeting.md)
