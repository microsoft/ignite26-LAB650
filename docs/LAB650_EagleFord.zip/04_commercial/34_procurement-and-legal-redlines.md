---
document_id: EF-034
account: EagleFord
document_date: 2026-08-13
document_type: "Negotiation workshop notes"
stage: "Legal negotiation"
author: "Erin Walsh, Commercial Counsel"
participants: "Erin Walsh; Dana Brooks; Noah Evans; Avery Stone; Grace Liu"
synthetic: true
---

# Procurement and legal redline workshop

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Review context

Erin consolidated EagleFord's comments on the enterprise proposal and draft agreement. This record summarizes positions for the simulation; it is not legal advice or an executed contract.

## Issues reviewed

| Topic | EagleFord position | Northstar position | Disposition |
|---|---|---|---|
| Availability | 99.95% requested | 99.9% proposed | Open |
| Liability | Higher protection for confidentiality and data events | Defined super-cap, limited exclusions | Open |
| Renewal | No automatic above-cap increase | Annual increase mechanism after initial term | Open |
| Data return | Usable export before deletion | Supported with defined process | Draft wording requested |
| Subprocessors | Advance notice and objection route | Notice plus reasonable mitigation | Open |
| Pilot credit | Exact reference on order and invoices | Agreed in principle | Finance confirmation needed |
| Scope changes | No surprise user overage | Written order required | Agreed in principle |

## Dialogue excerpts

**Erin:** “The business case does not give us room for ambiguous scope. If requesters are named users, say so plainly.”

**Avery:** “The 240 includes requesters, approvers, and administrators. There is no separate included requester pool and no automatic overage invoice.”

**Noah:** “We can document that. The service commitment must also define what is in the hosted service and what is in customer middleware.”

**Grace:** “We should not make a single availability percentage imply that Dynamics and the integration layer are under Northstar's control.”

## Operational terms

EagleFord requested security-event notification without waiting for full root-cause confirmation. Grace proposed notification without undue delay and an outer twenty-four-hour limit after confirmation of an incident affecting customer data. Erin will review the trigger carefully; a general support ticket is not automatically a confirmed security incident.

The group discussed thirteen months of searchable in-application audit events and seven-year retention in EagleFord-controlled immutable storage. The agreement must describe export support without implying Northstar stores every event in the application for seven years.

## Commercial controls

Noah will maintain the legal version; Avery will maintain the pricing version. Any change affecting cost, liability, or service scope requires a consolidated review. Verbal comments during the workshop do not amend the proposal.

## Next actions

Erin and Noah will exchange a clean issues list by August 18. Grace will bring the security closure evidence on August 20. Dana will confirm that the order form and statement of work describe the same population and workflow boundaries.

**Open risk:** a late liability disagreement could delay signature even if pricing is accepted. The account forecast must retain that dependency.

## Related records

- [EF-033: Commercial proposal: 240 named users and an explicit pilot credit](../04_commercial/33_pricing-proposal.md)
- [EF-035: Security closure record: pilot conditions resolved with production controls](../04_commercial/35_security-closure-record.md)
- [EF-037: Commercial negotiation transcript: discount, scope, and implementation risk](../04_commercial/37_commercial-negotiation-transcript.md)
- [EF-040: Executed agreement summary and order reconciliation](../04_commercial/40_executed-agreement-summary.md)
