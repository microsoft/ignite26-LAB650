---
document_id: EF-032
account: EagleFord
document_date: 2026-07-30
document_type: "Financial review transcript"
stage: "Financial approval"
author: "Avery Stone, Account Executive"
participants: "Maya Chen; Luis Ortega; Dana Brooks; Jo Ellis; Avery Stone; Quinn Foster"
synthetic: true
---

# CFO review transcript: capacity is not cash

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Review objective

Maya reviewed the July 23 business case, including its limitations. The meeting established her decision criteria but did not approve the current commercial terms.

## Transcript

**[00:04] Maya:** Your headline is $253,368 of annual value. How much of that can I remove from next year's budget?

**[00:06] Jo:** The $96,768 capacity component is not a budget reduction. The expedite component may reduce external cost if the emergency share changes. The $90,000 leakage component is still an estimate.

**[00:09] Maya:** Then do not headline it as savings. I see a first-year model that barely breaks even before our own project time.

**[00:11] Avery:** That is correct. The base net is $1,368 before internal implementation cost and ramp. We included a downside that does not cover the subscription.

**[00:15] Luis:** The control improvement matters. I need fewer ambiguous purchases and better visibility. But I agree we should not pretend that every minute released becomes cash.

**[00:20] Maya:** What changes the decision? Lower cost, smaller scope, or stronger evidence?

**[00:22] Dana:** A phased deployment reduces operational risk. It does not necessarily lower the license population. Procurement will need a clear license definition and no surprise requester charges.

**[00:26] Quinn:** We can formalize a 240-named-user enterprise scope and a three-year offer. I will not promise a lower number in this meeting without pricing approval.

**[00:30] Maya:** I also want the pilot credit reconciled. Eighteen thousand cannot disappear into the story and reappear on an invoice.

**[00:32] Avery:** The intended total implementation fee is $72,000, including the $18,000 pilot. Remaining implementation would be $54,000. Subscription would be separate.

**[00:37] Maya:** Bring me a final commercial package, the internal delivery commitment, and security closure. If we proceed, I want benefit owners and a review that can tell us the value did not materialize.

## Decisions

Maya accepts the analysis format, not the purchase. She requires named benefit owners, a downside view, transparent credit treatment, and a production-readiness plan. She will consider the control case alongside economics but will not approve fabricated financial precision.

## Actions

Avery will issue an explicit-scope proposal. Tessa will estimate customer delivery capacity. Dana will validate license roles. Jo will separate capacity and external-cost evidence in ongoing reporting.

**Sales interpretation:** Maya is the economic buyer and has engaged constructively. She has not committed budget or accepted the proposed subscription price.

## Related records

- [EF-031: Business case: a thin first-year base case, not guaranteed cash savings](../04_commercial/31_business-case-model.md)
- [EF-033: Commercial proposal: 240 named users and an explicit pilot credit](../04_commercial/33_pricing-proposal.md)
- [EF-038: Internal concession approval and forecast review](../04_commercial/38_concession-approval-memo.md)
- [EF-039: Executive decision meeting: proceed for control, with accountable economics](../04_commercial/39_executive-decision-meeting.md)
