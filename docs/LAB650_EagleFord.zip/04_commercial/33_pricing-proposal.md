---
document_id: EF-033
account: EagleFord
document_date: 2026-08-06
document_type: "Pricing proposal"
stage: "Commercial negotiation"
author: "Avery Stone, Account Executive"
participants: "Dana Brooks; Maya Chen; Avery Stone; Quinn Foster"
synthetic: true
---

# Commercial proposal: 240 named users and an explicit pilot credit

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Proposed scope

FieldBridge enterprise subscription for **240 named users** across **twelve EagleFord locations**, including requesters, approvers, and administrators. Users are named, not concurrent. Pilot users are included within the 240.

This proposal includes procurement intake, configured approval workflows, workflow reporting, agreed audit export, and the defined Dynamics integration work. It excludes invoice automation, supplier onboarding, warehouse inventory management, and full offline submission.

## Proposed commercial terms

| Item | Amount | Treatment |
|---|---:|---|
| Annual subscription list | $216,000 | Reference price |
| Proposed annual subscription | **$180,000** | Three-year commitment |
| Annual reduction from list | $36,000 | Approximately 16.7% |
| One-time implementation | **$72,000** | Includes paid pilot credit |
| Pilot already paid | ($18,000) | Credit against implementation only |
| Remaining implementation | **$54,000** | Proposed two milestone invoices of $27,000 |

The three-year subscription total is $540,000. Adding implementation gives **$612,000 total economic commitment**, including the pilot. Remaining commitment after the paid pilot would be **$594,000**. First-year economic cost would be $252,000; first-year amounts still to be paid after the pilot would be $234,000, before tax.

## Proposed schedule and billing

Target term: October 1, 2026–September 30, 2029. Annual subscription invoiced in advance. The implementation balance is proposed at configuration acceptance and first-wave go-live.

Phased deployment begins with North Mesa and Red Creek. A twelve-location license entitlement does not mean all locations are live on day one. Customer resource availability and readiness gates influence the schedule.

## Boundaries

Additional named users require an approved order; no automatic overage billing is proposed. Additional workflow families or material integration changes require written change control. The proposal does not include free warehouse-management functionality.

Proposed service terms are 99.9% monthly availability, eight-hour RTO, and four-hour RPO, subject to the negotiated agreement's definitions and exclusions.

## Conditions and validity

This is a fictional proposal, not an executed agreement. Enterprise use requires security closure, acceptable legal terms, final scope approval, and authorized signatures. The pilot-credit eligibility deadline remains September 30.

## Customer questions requested

Dana should verify the 240-user count and role coverage. Maya should confirm the economic treatment of capacity benefits. Erin should consolidate contractual comments. The account team will respond through one controlled commercial version rather than negotiating competing versions in separate emails.

## Related records

- [EF-021: Pilot statement of work: two locations, bounded evidence](../03_validation/21_pilot-statement-of-work.md)
- [EF-031: Business case: a thin first-year base case, not guaranteed cash savings](../04_commercial/31_business-case-model.md)
- [EF-034: Procurement and legal redline workshop](../04_commercial/34_procurement-and-legal-redlines.md)
- [EF-037: Commercial negotiation transcript: discount, scope, and implementation risk](../04_commercial/37_commercial-negotiation-transcript.md)
- [EF-040: Executed agreement summary and order reconciliation](../04_commercial/40_executed-agreement-summary.md)
