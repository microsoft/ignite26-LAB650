---
document_id: EF-036
account: EagleFord
document_date: 2026-08-26
document_type: "Fictional reference-call summary"
stage: "Commercial validation"
author: "Avery Stone, Account Executive"
participants: "Dana Brooks; Owen Park; Lena Ortiz; Jordan Vale, fictional reference customer"
synthetic: true
---

# Reference-call summary: what another operator wished it had planned

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Reference context

The reference organization, **CanyonSpan Utilities**, and its operations lead, **Jordan Vale**, are fictional. This document simulates a peer conversation; it is not a real testimonial or independent product verification.

EagleFord asked for lessons about adoption, integration ownership, and support after the implementation team leaves. Avery introduced the call and then stayed largely silent.

## Discussion

**Dana:** What did your team underestimate?

**Jordan:** The number of old requests that existed in somebody's inbox but not in an official register. We spent more time deciding which ones to migrate than configuring the form.

**Owen:** Who handles an ERP timeout now?

**Jordan:** Our integration operator. Initially people sent screenshots to the account executive. That worked while the project was small and failed as an operating model. We wrote a runbook with one business key and a clear rule about who could replay.

**Dana:** Did you realize the expected labor savings?

**Jordan:** We created capacity. We did not remove positions. The business accepted that distinction, but it should have been explicit earlier. We also had to stop managers using raw request counts as a performance ranking.

**Lena:** Which training format worked?

**Jordan:** Short sessions tied to a real task. Our longer platform tour produced attendance, not confidence. The most useful exercise was a request that failed halfway through.

## Implications for EagleFord

The call supports a disciplined delivery approach, not a financial assumption. Jordan's experience cannot be used to increase EagleFord's savings estimate. Different sites, rules, and staffing produce different outcomes.

Owen requested a runbook rehearsal before production. Dana requested a migration policy that avoids importing every email thread. Lena suggested tracking the time to a user's first successful request separately from training attendance.

## Concerns raised

Jordan described slower adoption at a remote location where local leadership did not reinforce the process. That experience makes the proposed twelve-location license scope different from a twelve-location deployment success. EagleFord must nominate site sponsors before expansion.

## Actions

- Tessa will define open-request migration criteria and exclusions.
- Marcus will schedule a timed exception-recovery rehearsal.
- Lena will include site-sponsor engagement in the success plan.
- Avery will preserve the reference caveats in the account notes.

**Decision impact:** Dana considers the reference useful and sees no new fit blocker. The call does not constitute a procurement award or a guarantee of implementation timing.

## Related records

- [EF-031: Business case: a thin first-year base case, not guaranteed cash savings](../04_commercial/31_business-case-model.md)
- [EF-037: Commercial negotiation transcript: discount, scope, and implementation risk](../04_commercial/37_commercial-negotiation-transcript.md)
- [EF-041: Sales-to-success handoff: promises, limitations, and the customer narrative](../05_delivery/41_sales-to-success-handoff.md)
- [EF-044: Migration rehearsal: carry open work, not every historical message](../05_delivery/44_migration-rehearsal.md)
