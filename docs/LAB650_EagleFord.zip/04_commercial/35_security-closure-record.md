---
document_id: EF-035
account: EagleFord
document_date: 2026-08-20
document_type: "Security and control acceptance"
stage: "Security approval"
author: "Simone Reed, Security Lead"
participants: "Simone Reed; Grace Liu; Owen Park; Priya Nair; Dana Brooks; Rowan Patel"
synthetic: true
---

# Security closure record: pilot conditions resolved with production controls

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Review decision

Simone accepts the defined security-control design for the proposed production scope. This closes the two conditional pilot cases at the design-and-evidence level. Production activation still requires the deployment checklist, current access roster, and operational handoff.

## T13: delegation expiry

The configured customer identity-and-workflow control assigns a substitute approver with an explicit end date. A scheduled policy job revokes the assignment at expiry and records the action. The requester cannot become the approving delegate for the same request.

Evidence includes an expired-assignment test, a cross-location denial, a self-approval denial, and a job-failure alert. Dana approved the authority mapping. Owen owns the scheduled-job monitor. The fallback is a documented administrator removal, not permission for delegation to persist indefinitely.

## T22: audit export and independent retention

The scheduled export sends the agreed event fields to EagleFord-controlled storage. Immutable retention is configured for seven years on the customer side. FieldBridge provides thirteen months of searchable in-application event history.

The team demonstrated an export, reconciled record counts, read back a retained sample, and triggered an alert for an intentionally failed delivery. Owen owns delivery monitoring; Simone's team owns retention-policy review. A failed export is an operational exception that cannot be treated as a successful backup.

## Accepted commitments and responsibilities

| Area | Accepted design |
|---|---|
| Identity | Entra ID SSO, customer-managed conditional access |
| Scope | Role and location restrictions with negative tests |
| Region | US-hosted production tenant |
| Support access | Time-bound, justified, logged access under the approved procedure |
| Data minimization | No banking, health, payment-card, or detailed safety-incident data required |
| Exit | Export window and deletion workflow to be captured in final terms |

Contractual incident wording and liability are still being finalized by counsel. Security acceptance does not resolve every commercial term.

## Residual risks

No full offline submission is available. Administrators can still misconfigure authorized rules; change review and periodic access recertification remain necessary. End-to-end recovery depends on customer middleware and Dynamics as well as FieldBridge.

The June incident demonstrates why callback integrity and financial integrity must be monitored separately. Zero duplicate POs in that event does not eliminate the need for status reconciliation.

## Signoff boundary

Priya accepts the architecture subject to production checklist completion. Simone accepts these control designs and evidence. Neither has authorized twelve-location activation or accepted a future expansion scope.

**Next step:** carry these owners and tests into the customer-success handoff and require deployment evidence before the first production wave.

## Related records

- [EF-014: Security intake: evidence requested and statements not yet accepted](../02_solution_design/14_security-questionnaire.md)
- [EF-017: Nonfunctional requirements and production-readiness gates](../02_solution_design/17_nonfunctional-requirements.md)
- [EF-028: Corrective-action review: controlled replay and remaining pilot conditions](../03_validation/28_workaround-and-retest.md)
- [EF-040: Executed agreement summary and order reconciliation](../04_commercial/40_executed-agreement-summary.md)
- [EF-041: Sales-to-success handoff: promises, limitations, and the customer narrative](../05_delivery/41_sales-to-success-handoff.md)
