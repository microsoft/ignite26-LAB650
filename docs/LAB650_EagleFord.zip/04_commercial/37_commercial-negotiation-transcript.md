---
document_id: EF-037
account: EagleFord
document_date: 2026-09-03
document_type: "Negotiation transcript"
stage: "Commercial negotiation"
author: "Avery Stone, Account Executive"
participants: "Dana Brooks; Erin Walsh; Maya Chen; Avery Stone; Quinn Foster; Noah Evans"
synthetic: true
---

# Commercial negotiation transcript: discount, scope, and implementation risk

> Fictional sales simulation. All organizations, people, dialogue, figures, and events in this document are invented for this exercise. Statements represent the information available on the document date.

## Positions entering the meeting

Northstar's current offer is $180,000 annually for 240 named users, plus $72,000 implementation inclusive of the $18,000 paid pilot credit. EagleFord asks for $165,000 annual pricing, stronger renewal protection, and confidence that the rollout will not become a series of change orders.

## Transcript

**[00:05] Maya:** Our first-year case is not generous. I want either a lower subscription or a structure that makes the delivery risk explicit.

**[00:08] Avery:** The annual price already reflects a $36,000 reduction from the $216,000 list. We can examine payment and implementation structure, but I cannot agree to $165,000 today.

**[00:12] Dana:** We do not want a discount funded by removing training. The field still has to use this.

**[00:15] Quinn:** Agreed. We should preserve the scoped enablement. I can review a price lock during the initial term and a defined renewal cap, in exchange for the three-year commitment and agreed scope.

**[00:20] Erin:** A renewal cap is useful only if you cannot reclassify the same users or modules at renewal.

**[00:23] Noah:** We can define the current scope and make material changes an explicit order. The cap would apply to like-for-like scope; counsel should make that precise.

**[00:28] Maya:** What is still excluded?

**[00:29] Avery:** Invoice automation, supplier onboarding, warehouse inventory, and full offline submission. The 240-user scope includes requesters, approvers, and administrators. There is no automatic excess-user invoice.

**[00:34] Dana:** What if the third site needs a different approval structure?

**[00:35] Quinn:** Configuration within the agreed templates is included. A new workflow family or material integration change requires written assessment. We should define examples in the statement of work.

## Negotiation status

No revised price was accepted. EagleFord withdrew no legal concerns. Northstar will review a capped like-for-like renewal increase, staged implementation balance, and explicit change-control examples. A higher availability request remains open.

## Actions

Noah and Erin will resolve liability and service language. Quinn will approve a controlled concession package by September 10. Avery will issue one consolidated version.

**Sales discipline:** do not tell the delivery team the deal is closed or promise free expansion to protect a signature date. A concession must be approved and documented before it is offered as final.

## Related records

- [EF-033: Commercial proposal: 240 named users and an explicit pilot credit](../04_commercial/33_pricing-proposal.md)
- [EF-034: Procurement and legal redline workshop](../04_commercial/34_procurement-and-legal-redlines.md)
- [EF-038: Internal concession approval and forecast review](../04_commercial/38_concession-approval-memo.md)
- [EF-039: Executive decision meeting: proceed for control, with accountable economics](../04_commercial/39_executive-decision-meeting.md)
